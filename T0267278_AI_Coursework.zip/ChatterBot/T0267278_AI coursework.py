#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Basic chatbot design 
"""
#  pip install azure.cognitiveservices.vision.computervision
# pip install wikipedia
# Import required libraries
from azure.cognitiveservices.vision.computervision import ComputerVisionClient
from msrest.authentication import CognitiveServicesCredentials
import requests, uuid, json
import matplotlib.pyplot as plt
from PIL import Image, ImageDraw
import os
import csv
import difflib
import nltk
from nltk.tokenize import word_tokenize
from nltk.stem import WordNetLemmatizer
from nltk.sem import logic
from nltk.sem.logic import LogicParser
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity


#  Initialise AIML agent
import aiml
from nltk.sem import Expression
from nltk.inference import ResolutionProver
read_expr = Expression.fromstring



# Initialize the lemmatizer and stop words #new
lemmatizer = WordNetLemmatizer()

# Get the directory path of the current file
dir_path = os.path.dirname(os.path.abspath(__file__))

# Get the list of files in the directory 
files = os.listdir(dir_path)
# Find the knowledgebase.csv file
for file in files:
    if file == 'knowledgebase.csv':
        knowledgebase_path = os.path.join(dir_path, file)
        break
# Initialise and Read the knowledgebase file
import pandas
kb=[]
data = pandas.read_csv(knowledgebase_path, header=None)
[kb.append(read_expr(row)) for row in data[0]]


# Create a Kernel object. No string encoding (all I/O is unicode)
kern = aiml.Kernel()
kern.setTextEncoding(None)
if os.path.isfile("bot_brain.brn"):
    kern.bootstrap(brainFile = "bot_brain.brn")
else:
    kern.bootstrap(learnFiles = "startup.xml", commands = "load aiml b")
    kern.saveBrain("bot_brain.brn")
# Use the Kernel's bootstrap() method to initialize the Kernel. The
# optional learnFiles argument is a file (or list of files) to load.
# The optional commands argument is a command (or list of commands)
# to run after the files are loaded.
# The optional brainFile argument specifies a brain file to load.
kern.bootstrap(learnFiles="C:\\Users\\marco\ChatterBot\\fruit_aiml.aiml")

# Load custom AIML files related to fruit topic
fruit_aiml_files = os.listdir(os.path.dirname(os.path.abspath("fruit_aiml")))

for file in fruit_aiml_files:
    kern.learn(os.path.join("C:\\Users\\marco\ChatterBot\\fruit_aiml", file))

# Read the QA pairs from the CSV file and store them in a dictionary

qa_pairs = []
with open("C:\\Users\\marco\ChatterBot\\qa_pairs.csv", mode='r', encoding='utf-8') as file:
    reader = csv.reader(file)
    print("QA pairs read")
    for row in reader:
        qa_pairs.append(row)





# Set up the Computer Vision client and Text Translator API key and endpoint
cog_key = 'ca46421f3add47ab8c0f0d2f77f511fd'
cog_endpoint = 'https://myservice1.cognitiveservices.azure.com/'
cog_region = 'uksouth'

print('Ready to use cognitive services in {} using key {}'.format(cog_region, cog_key))

# Function to translate text using Text Translation service
def translate_text(cog_region, cog_key, text, to_lang='fr', from_lang='en'):
    # Create the URL for the Text Translator service REST request
    path = 'https://api.cognitive.microsofttranslator.com/translate?api-version=3.0'
    params = '&from={}&to={}'.format(from_lang, to_lang)
    constructed_url = path + params

    # Prepare the request headers with Cognitive Services resource key and region
    headers = {
        'Ocp-Apim-Subscription-Key': cog_key,
        'Ocp-Apim-Subscription-Region':cog_region,
        'Content-type': 'application/json',
        'X-ClientTraceId': str(uuid.uuid4())
    }

    # Add the text to be translated to the body
    body = [{
        'text': text
    }]

    # Get the translation
    request = requests.post(constructed_url, headers=headers, json=body)
    response = request.json()
    return response[0]["translations"][0]["text"]


# Function to process image and output translated text
def process_image(image_filename, target_language):
    # Set up Computer Vision client and read image file
    computervision_client = ComputerVisionClient(cog_endpoint, CognitiveServicesCredentials(cog_key))
    image_path = os.path.join('data', 'ocr', image_filename)
    image_stream = open(image_path, "rb")

    # Use Computer Vision service to find text in the image
    read_results = computervision_client.recognize_printed_text_in_stream(image_stream)

    # Process the text line by line
    for region in read_results.regions:
        for line in region.lines:
            # Read the words in the line of text
            line_text = ''
            for word in line.words:
                line_text += word.text + ' '

            # Translate text if it matches target language
            if line_text.rstrip() == 'Exit' and target_language != 'en':
                translated_text = translate_text(cog_region, cog_key, 'Exit', to_lang=target_language, from_lang='en')
                print(translated_text)
            elif target_language != 'en':
                translated_text = translate_text(cog_region, cog_key, line_text.rstrip(), to_lang=target_language)
                print(translated_text)
            else:
                print(line_text.rstrip())


# Define a function to preprocess the text #new
def preprocess_text(text):
    # Tokenize the text
    tokens = nltk.word_tokenize(text.lower())
    # Remove stop words and lemmatize the tokens
    tokens = [lemmatizer.lemmatize(token) for token in tokens if token not in stop_words]
    # Join the tokens back into a string
    preprocessed_text = ' '.join(tokens)
    return preprocessed_text



def lemmatize_sentence(sentence):
    lemmatizer = WordNetLemmatizer()
    tokens = word_tokenize(sentence)
    lemmatized_sentence = ' '.join([lemmatizer.lemmatize(token) for token in tokens])
    return lemmatized_sentence


def get_most_similar_question(userInput, qa_pairs):
    lemmatized_user_input = lemmatize_sentence(userInput)
    corpus = [lemmatize_sentence(qa_pair[0]) for qa_pair in qa_pairs]
    vectorizer = TfidfVectorizer()
    X = vectorizer.fit_transform(corpus)
    user_input_vector = vectorizer.transform([lemmatized_user_input])
    similarities = cosine_similarity(user_input_vector, X).flatten()
    most_similar_question_index = similarities.argmax()
    return qa_pairs[most_similar_question_index][1]




def get_response(userInput, qa_pairs):
    response = None
    for qa_pair in qa_pairs:
        if qa_pair[0] == userInput:
            response = qa_pair[1]
            break
    if not response:
        response = get_most_similar_question(userInput, qa_pairs)
    return response
    # Otherwise, use AIML to generate a response
    return kern.respond(userInput)



def generate_response(userInput):
    # Check the AIML files for a response
    aiml_response = kern.respond(userInput)

    # Check the CSV file for a response
    csv_response = None
    input_text_lemmatized = ' '.join([lemmatizer.lemmatize(w.lower()) for w in word_tokenize(userInput)])
    input_text_tfidf = TfidfVectorizer().fit_transform([input_text_lemmatized])
    max_sim = 0
    for row in qa_pairs:
        question = row[0]
        question_lemmatized = ' '.join([lemmatizer.lemmatize(w.lower()) for w in word_tokenize(question)])
        question_tfidf = TfidfVectorizer().fit_transform([question_lemmatized])
        sim = cosine_similarity(input_text_tfidf, question_tfidf)[0][0]
        if sim > max_sim:
            max_sim = sim
            csv_response = row[1]
    if max_sim > 0.5:
        return csv_response
    else:
        return aiml_response


    
# Load the initial KB from CSV file
def load_knowledge_base():
    kb = []
    with open('C:\\Users\\marco\ChatterBot\\knowledgebase.csv', 'r', encoding='utf-8') as f:
        reader = csv.reader(f)
        for row in reader:
            kb.append(row)
    return kb


# Save the updated KB to CSV file
def save_knowledge_base(kb):
    with open('C:\\Users\\marco\ChatterBot\\knowledgebase.csv', 'w', newline='', encoding='utf-8') as f:
        writer = csv.writer(f)
        writer.writerows(kb)

# Check if fact is true, false or unknown
def check_fact(fact, kb):
    parser = LogicParser()
    expr = parser.parse(fact)
    prover = ResolutionProver()
    known_facts = [parser.parse(fact[0]) for fact in kb]
    if expr in known_facts:
        return "Correct."
    elif prover.prove(expr, known_facts):
        return "Correct."
    else:
        return "Sorry, I don't know."

# Check the integrity of the KB
def check_integrity(kb):
    parser = LogicParser()
    exprs = [parser.parse(fact[0]) for fact in kb]
    prover = ResolutionProver()
    return all(prover.prove(expr) is not None for expr in exprs)

#C:\Users\marco\Downloads\ai-fundamentals-master\ai-fundamentals-master\data\ocr\letter.jpg  
# Prompt user for image filename and target language
#image_filename = input("Enter the image filename: ")
#target_language = input("Enter the target language (e.g. 'fr' for French): ")

# Process the image and output translated text
#process_image(image_filename, target_language)


# Welcome user
print("Welcome to this chat bot. Please feel free to ask questions from me!")


# Main loop
while True:
    #get user input
    try:
        userInput = input("User: ")
        response = kern.respond(userInput)
       # response = get_response(userInput, qa_pairs)
        print("Chatbot:" + response)
        if userInput.lower() == 'quit':
            break
        elif userInput.lower() == 'language':
            source_lang = input('What is the source language? (e.g. fr for French, zh-CN for Chinese):')  #zh-CN, en, fr
            target_lang = input('What is the target language? ')
            while True:
                text_to_translate = input('Enter a sentence to translate (or "back" to return to the main chat): ')
                if text_to_translate.lower() == 'back':
                    break
                else:
                    translation = translate_text(cog_region, cog_key, text_to_translate, to_lang=target_lang, from_lang=source_lang)
                    print('Translated text: {}'.format(translation))
        elif userInput.lower() == 'image':
            # Prompt user for image filename and target language
            image_filename = input("Enter the image filename: ")
            target_language = input("Enter the target language (e.g. 'fr' for French): ")
            # Process the image and output translated text
            process_image(image_filename, target_language)
        elif userInput.lower() == 'more':
            userInput = input("User: ")
            response = get_response(userInput, qa_pairs)
            print("Chatbot:" + response)
        
        elif userInput.lower()=="Check that ":
            fact_parts = userInput[12:].split(' is ')
            if len(fact_parts) == 2:
                object, subject = fact_parts
                expr = read_expr(subject + '(' + object + ')')
                prover = ResolutionProver()
            elif prover.prove(expr, kb):
                prover = ResolutionProver()
                kb.append(expr)
                response =('Correct')
            else:
                print('This statement contradicts with the knowledgebase.')
        
        elif userInput.lower()=="I know that ":
            fact_parts = userInput[12:].split(' is ')
            if len(fact_parts) == 2:
                object, subject = fact_parts
                expr = read_expr(subject + '(' + object + ')')
                prover = ResolutionProver()
            elif prover.prove(expr, kb):
                prover = ResolutionProver()
                kb.append(expr)
                response =('OK, I will remember that.')
            else:
                print('This statement contradicts with the knowledgebase.')
    
    except (KeyboardInterrupt, EOFError) as e:
        print("Bye!")
        break