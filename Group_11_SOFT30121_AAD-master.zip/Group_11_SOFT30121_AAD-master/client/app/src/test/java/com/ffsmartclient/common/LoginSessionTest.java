package com.ffsmartclient.common;

import static org.junit.Assert.*;
import static org.mockito.MockitoAnnotations.initMocks;
import static org.powermock.api.mockito.PowerMockito.mock;
import static org.powermock.api.mockito.PowerMockito.mockStatic;
import static org.powermock.api.mockito.PowerMockito.when;
import static org.powermock.api.mockito.PowerMockito.whenNew;

import com.blankj.utilcode.util.SPUtils;
import com.ffsmartclient.model.LoginToken;
import com.ffsmartclient.model.User;
import com.ffsmartclient.utils.MyJsonUtil;
import com.ffsmartclient.utils.httputils.Response;


import org.junit.Before;
import org.junit.Test;


import org.junit.runner.RunWith;

import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;


@RunWith(PowerMockRunner.class)
@PrepareForTest({LoginSession.class, SPUtils.class})
public class LoginSessionTest {
    @Mock
    private MyJsonUtil myJsonUtil;
    @Before
    public void setUp() {
        mockStatic(LoginSession.class);
        initMocks(this);
        System.out.println("New Test Begin =>");
    }
    @Test
    public void testGetUid() {
        String expectedUserId = "63e018d851f4491179db9fbc";
        User user = new User();
        user.setId("63e018d851f4491179db9fbc");
        user.setEmail("wj@gmail.com");
        user.setPassword("$2a$12$JS9nd2OoHljvpqxlUDI8M.Ze/ccZQBVbjzLh8GDNQb8qSGuzCPcp2");
        user.setFirstName("Wenjia");
        user.setLastName("G");
        user.setRole(2);
        user.setAvatar(null);
        when(LoginSession.getUser()).thenReturn(user);
        when(LoginSession.getUid()).thenCallRealMethod();
        String aUid = LoginSession.getUid();
        assertEquals(expectedUserId, aUid);
    }

    @Test
    public void testGetUser() {
        User user = new User();
        user.setId("63e018d851f4491179db9fbc");
        user.setEmail("wj@gmail.com");
        user.setPassword("$2a$12$JS9nd2OoHljvpqxlUDI8M.Ze/ccZQBVbjzLh8GDNQb8qSGuzCPcp2");
        user.setFirstName("Wenjia");
        user.setLastName("G");
        user.setRole(2);
        user.setAvatar(null);

        String expectedUserJson = "{\"id\":\"63e018d851f4491179db9fbc\",\"email\":\"wj@gmail.com\"," +
                "\"password\":\"$2a$12$JS9nd2OoHljvpqxlUDI8M.Ze/ccZQBVbjzLh8GDNQb8qSGuzCPcp2\",\"firstName\":" +
                "\"Wenjia\",\"lastName\":\"G\",\"role\":2}";

        when(LoginSession.getUser()).thenReturn(user);
        String aUser = myJsonUtil.toJson(user);
        assertEquals(expectedUserJson, aUser);
    }

}