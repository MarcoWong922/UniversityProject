package com.ffsmartclient.utils.httputils;

import static org.junit.Assert.*;

import com.ffsmartclient.model.Inventory;
import com.ffsmartclient.model.LoginCredential;
import com.ffsmartclient.utils.MyJsonUtil;
import com.google.gson.reflect.TypeToken;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

public class MyHttpUtilTest {

    @Mock
    private MyHttpUtil myHttpUtil;

    String result;

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
        System.out.println("New Test Begin =>");
    }

    @Test
    public void testPostSuccess() {
        LoginCredential login = new LoginCredential();
        login.setEmail("wj@gmail.com");
        login.setPassword("123123a");
        String expectedSuccessResponseJson = "{\"data\":{\"token\":\"eyJhbGciOiJIUzUxMiJ9.eyJyb2xlIjpbIlJPT" +
                "EVfSEVBRF9DSEVGIl0sInN1YiI6IjYzZTAxOGQ4NTFmNDQ5MTE3OWRiOWZiYyIsImlhdCI6MTY3NTYzMDgwO" +
                "CwiZXhwIjoxNjc1NjM0NDA4fQ.ymEfMX5fSHY3ysviBcZaXCTyXBfpsPqJrtN2JHPBnExKmSpBpjc8Ep-p8MgkG" +
                "iF5ImpcaF8A1cm4eJLTbRP32g\",\"user\":{\"id\":\"63e018d851f4491179db9fbc\",\"email\":" +
                "\"wj@gmail.com\",\"password\":\"$2a$12$JS9nd2OoHljvpqxlUDI8M.Ze/ccZQBVbjzLh8GDNQb8qSGuzCPcp2\"," +
                "\"firstName\":\"Wenjia\",\"lastName\":\"G\",\"role\":2,\"avatar\":null}},\"message\":\"Success\"}";

        MyHttpUtil.post(MyUrlConfig.user + "/login", login, "POST", new MyHttpCallbackUtil() {
            @Override
            public void onSuccess(String data) {
                result = data;
                assertNotNull(result);
                assertEquals(expectedSuccessResponseJson, result);
            }
            @Override
            public void onFailure(String data) {
            }
        });
    }


    @Test
    public void testPostFailure() {
        LoginCredential login = new LoginCredential();
        login.setEmail("wj@gmail.com");
        login.setPassword("123123c");

        String expectedStatus = "404";
        String expectedMessage = "User not found";

        myHttpUtil.post(MyUrlConfig.user + "/login", login, "POST", new MyHttpCallbackUtil() {
            @Override
            public void onSuccess(String data) {
            }

            @Override
            public void onFailure(String data) {
                FailureResponse<String> result = MyJsonUtil.fromJson(data, new TypeToken<FailureResponse<String>>() {
                }.getType());
                assertNotNull(result);
                assertEquals(expectedStatus, result.getStatus());
                assertEquals(expectedMessage, result.getMsg());
            }
        });
    }

    @Test
    public void testPostWithTokenSuccess() {
        Inventory inventoryItem = new Inventory(null, "0", "Bananas 100g",
                "63d1b3dae8b8e7e8b68300af", "Supplier 1", 3, "2023-02-12");
        String expectedSuccessResponseJson = "{\"data\":{\"id\":\"63e01ffc51f4491179db9fbe\",\"userId\":" +
                "\"63e018d851f4491179db9fbc\",\"items\":[{\"id\":\"63e01ffc51f4491179db9fbd\",\"itemId\":" +
                "\"0\",\"itemName\":\"Bananas 100g\",\"supplierId\":\"63d1b3dae8b8e7e8b68300af\",\"supplierName\":" +
                "\"Supplier 1\",\"quantity\":3,\"expiryDate\":\"2023-02-12\"}],\"operation\":1,\"date\":\"2023-02-05\"}" +
                ",\"message\":\"Success\"}";

        myHttpUtil.postWithToken(MyUrlConfig.inventory + "/insert", inventoryItem,"POST", new MyHttpCallbackUtil() {
            @Override
            public void onSuccess(String data) {
                String result = data;
                assertNotNull(result);
                assertEquals(expectedSuccessResponseJson, result);
            }

            @Override
            public void onFailure(String data) {

            }
        });
    }

    @Test
    public void testPostWithTokenFailure() {
        Inventory inventoryItem = new Inventory(null, "0", "Bananas 100g",
                "63d1b3dae8b8e7e8b68300af", "Supplier 1", 3, null);
        int expectedStatus = 400;
        String expectedMessage = "Failed to read HTTP message";

        myHttpUtil.getWithToken(MyUrlConfig.supplier + "/" + inventoryItem, "GET", new MyHttpCallbackUtil() {
            @Override
            public void onSuccess(String data) {
            }

            @Override
            public void onFailure(String data) {
                FailureResponse<String> result = MyJsonUtil.fromJson(data, new TypeToken<FailureResponse<String>>() {
                }.getType());
                assertEquals(expectedStatus, result.getStatus());
                assertEquals(expectedMessage, result.getMsg());
            }
        });
    }

    @Test
    public void testGetWithTokenSuccess() {
        String supplier_id = "63d1b3dae8b8e7e8b68300af";
        String expectedSuccessResponseJson = "{\"data\":{\"id\":\"63d1b3dae8b8e7e8b68300af\"," +
                "\"name\":\"Supplier 1\",\"items\":[{\"id\":\"0\",\"name\":" +
                "\"Bananas 100g\",\"supplierId\":null,\"supplierName\":null},{\"id\":\"6\"," +
                "\"name\":\"Milk 2L\",\"supplierId\":null,\"supplierName\":null},{\"id\":\"2\"," +
                "\"name\":\"Lamb 500g\",\"supplierId\":null,\"supplierName\":null}],\"email\":" +
                "\"supplier1@gmail.com\",\"phone\":\"07577123123\"},\"message\":\"Success\"}";

        myHttpUtil.getWithToken(MyUrlConfig.supplier + "/" + supplier_id, "GET", new MyHttpCallbackUtil() {
            @Override
            public void onSuccess(String data) {
                String result = data;
                assertNotNull(result);
                assertEquals(expectedSuccessResponseJson, result);
            }

            @Override
            public void onFailure(String data) {
            }
        });
    }

    @Test
    public void testGetWithTokenFailure() {
        String supplier_id = "123";
        int expectedStatus = 404;
        String expectedMessage = "Supplier not found";

        myHttpUtil.getWithToken(MyUrlConfig.supplier + "/" + supplier_id, "GET", new MyHttpCallbackUtil() {
            @Override
            public void onSuccess(String data) {
            }

            @Override
            public void onFailure(String data) {
                FailureResponse<String> result = MyJsonUtil.fromJson(data, new TypeToken<FailureResponse<String>>() {
                }.getType());
                assertEquals(expectedStatus, result.getStatus());
                assertEquals(expectedMessage, result.getMsg());
            }
        });
    }
}