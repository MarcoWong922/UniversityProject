package com.ffsmartclient.utils;

import static org.junit.Assert.*;
import static org.mockito.MockitoAnnotations.initMocks;
import static org.powermock.api.mockito.PowerMockito.mockStatic;
import static org.powermock.api.mockito.PowerMockito.when;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.ffsmartclient.model.LoginCredential;
import com.google.gson.reflect.TypeToken;

@RunWith(PowerMockRunner.class)
@PrepareForTest({MyJsonUtil.class})
public class MyJsonUtilTest {
    @Before
    public void setUp() {
        mockStatic(MyJsonUtil.class);
        initMocks(this);
        System.out.println("New Test Begin =>");
    }
    @Test
    public void testToJson() {
        LoginCredential loginObj = new LoginCredential();
        loginObj.setEmail("t1@gmail.com");
        loginObj.setPassword("123123b");
        String expectedJson = "{\"email\":\"t1@gmail.com\",\"password\":\"123123b\"}";
        when(MyJsonUtil.toJson(loginObj)).thenCallRealMethod();
        String result = MyJsonUtil.toJson(loginObj);
        assertNotNull(result);
        assertEquals(expectedJson, result);
    }

    @Test
    public void testFromJson() {
        String loginJson = "{\"email\":\"t1@gmail.com\",\"password\":\"123123b\"}";
        LoginCredential expectedObj = new LoginCredential();
        expectedObj.setEmail("t1@gmail.com");
        expectedObj.setPassword("123123b");
        when(MyJsonUtil.fromJson(loginJson, new TypeToken<LoginCredential>(){}.getType())).thenCallRealMethod();
        LoginCredential loginCredentialResult = MyJsonUtil.fromJson(loginJson, new TypeToken<LoginCredential>(){}.getType());
        assertNotNull(loginCredentialResult);
        assertEquals(expectedObj.getEmail(), loginCredentialResult.getEmail());
        assertEquals(expectedObj.getPassword(), loginCredentialResult.getPassword());
    }
}