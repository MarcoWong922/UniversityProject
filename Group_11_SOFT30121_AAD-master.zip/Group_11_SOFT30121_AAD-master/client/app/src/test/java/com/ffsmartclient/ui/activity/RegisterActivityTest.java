package com.ffsmartclient.ui.activity;

import static org.junit.Assert.assertEquals;
import static org.mockito.MockitoAnnotations.initMocks;
import static org.powermock.api.mockito.PowerMockito.when;

import org.junit.Before;
import org.junit.Test;

import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

public class RegisterActivityTest {
    @Mock
    private RegisterActivity registerActivity;
    @Before
    public void setUp() {
        initMocks(this);
        System.out.println("New Test Begin =>");
    }
    private void equalCheck(boolean expectedResult, boolean actualResult){
        assertEquals(expectedResult, actualResult);
    }
    @Test
    public void testCheckUserName_whenUserNameCorrect_thenCheckPass() {
        String firstName = "Wenjia";
        String lastName = "Geng";
        boolean expectedResult = true;
        when(registerActivity.checkUserName(firstName,lastName)).thenCallRealMethod();
        boolean actualResult = registerActivity.checkUserName(firstName,lastName);
        equalCheck(expectedResult,actualResult);
    }

    @Test
    public void testCheckUserName_whenFirstNameIsNull_thenCheckNotPass() {
        String firstName = "";
        String lastName = "Geng";
        boolean expectedResult = false;
        boolean actualResult = registerActivity.checkUserName(firstName,lastName);
        equalCheck(expectedResult,actualResult);
    }

    @Test
    public void testCheckUserName_whenLastNameNull_thenCheckNotPass() {
        String firstName = "Wenjia ";
        String lastName = "";
        boolean expectedResult = false;
        boolean actualResult = registerActivity.checkUserName(firstName,lastName);
        equalCheck(expectedResult,actualResult);
    }

    @Test
    public void testCheckEmailFormat_whenEmailCorrect_thenCheckPass() {
        String email = "t1@gmail.com";
        boolean expectedResult = true;
        when(registerActivity.checkEmailFormat(email)).thenCallRealMethod();
        boolean actualResult = registerActivity.checkEmailFormat(email);
        equalCheck(expectedResult,actualResult);
    }

    @Test
    public void testCheckEmailFormat_whenEmailNull_thenCheckNotPass() {
        String email = " ";
        boolean expectedResult = false;
        boolean actualResult = registerActivity.checkEmailFormat(email);
        equalCheck(expectedResult,actualResult);
    }

    @Test
    public void testCheckEmailFormat_whenEmailFormatWrong_thenCheckNotPass() {
        String email = "123";
        boolean expectedResult = false;
        boolean actualResult = registerActivity.checkEmailFormat(email);
        equalCheck(expectedResult,actualResult);
    }

    @Test
    public void testCheckPasswordFormat_whenPasswordCorrect_thenCheckPass() {
        String password = "123123b";
        boolean expectedResult = true;
        when(registerActivity.checkPasswordFormat(password)).thenCallRealMethod();
        boolean actualResult = registerActivity.checkPasswordFormat(password);
        equalCheck(expectedResult,actualResult);
    }

    @Test
    public void testCheckPasswordFormat_whenPasswordNull_thenCheckNotPass() {
        String password = "";
        boolean expectedResult = false;
        boolean actualResult = registerActivity.checkPasswordFormat(password);
        equalCheck(expectedResult,actualResult);
    }

    @Test
    public void testCheckPasswordFormat_whenPasswordFormatWrong_thenCheckNotPass() {
        String password = "123123";
        boolean expectedResult = false;
        boolean actualResult = registerActivity.checkPasswordFormat(password);
        equalCheck(expectedResult,actualResult);
    }

    @Test
    public void testCheckPasswordMatched_whenPasswordsMatched_thenCheckPass() {
        String password = "123123b";
        String cPassword = "123123b";
        boolean expectedResult = true;
        when(registerActivity.checkPasswordMatched(password, cPassword)).thenCallRealMethod();
        boolean actualResult = registerActivity.checkPasswordMatched(password, cPassword);
        equalCheck(expectedResult,actualResult);
    }

    @Test
    public void testCheckPasswordMatched_whenPasswordsNotMatched_thenCheckNotPass() {
        String password = "123123b";
        String cPassword = "123123a";
        boolean expectedResult = false;
        boolean actualResult = registerActivity.checkPasswordMatched(password, cPassword);
        equalCheck(expectedResult,actualResult);
    }




}