/*
 * NTU Wenjia Geng (c) All rights reserved
 * None of this code can be reproduced or partly re-used without the permission
 * from Wenjia Geng (wenjia.geng2020@my.ntu.ac.uk).
 */
package com.ffsmartclient;

import android.app.Application;

import com.blankj.utilcode.util.Utils;

/**
 * Class for starting the application
 *
 * @author Wenjia Geng
 */

public class MainApp extends Application {
    @Override
    public void onCreate() {
        super.onCreate();//test
        /**
         * Initialize the AndroidUtilCode tool library
         *  Reference: https://github.com/Blankj/AndroidUtilCode
         */
        Utils.init(this);
    }
}