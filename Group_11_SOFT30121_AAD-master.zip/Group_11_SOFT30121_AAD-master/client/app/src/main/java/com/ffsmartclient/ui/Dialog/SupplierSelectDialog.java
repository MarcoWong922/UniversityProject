/*
 * NTU Wenjia Geng (c) All rights reserved
 * None of this code can be reproduced or partly re-used without the permission
 * from Wenjia Geng (wenjia.geng2020@my.ntu.ac.uk).
 */
package com.ffsmartclient.ui.dialog;

import android.app.Dialog;
import android.content.Context;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import androidx.annotation.NonNull;

import com.ffsmartclient.model.Supplier;
import com.ffsmartclient.R;
import com.ffsmartclient.utils.httputils.FailureResponse;
import com.ffsmartclient.utils.httputils.MyHttpCallbackUtil;
import com.ffsmartclient.utils.httputils.MyHttpUtil;
import com.ffsmartclient.utils.httputils.MyUrlConfig;
import com.ffsmartclient.utils.httputils.Response;
import com.ffsmartclient.utils.MyJsonUtil;
import com.ffsmartclient.utils.MyToastUtil;
import com.ffsmartclient.ui.adapter.MyAdapter;
import com.ffsmartclient.ui.adapter.ViewHolder;
import com.google.gson.reflect.TypeToken;

import java.util.List;

/**
 * Suppliers Select Dialog
 *
 * @author Wenjia Geng
 */

public class SupplierSelectDialog extends Dialog {

    private EditText edit_search;
    private Button btn_search;
    private ListView listView;
    private List<Supplier> supplierList;

    public SupplierSelectDialog(@NonNull Context context, SupplierSelectDialog.Callback callback) {
        super(context);
        setContentView(R.layout.dialog_supplier);
        //Display dialog
        show();
        edit_search = findViewById(R.id.edit_search);
        btn_search = findViewById(R.id.btn_search);
        listView = findViewById(R.id.listView);

        listView.setOnItemClickListener((adapterView, view, i, l) -> {
            if (supplierList != null && supplierList.size() > i) {
                Supplier supplier = supplierList.get(i);
                callback.onCall(supplier);
                dismiss();
            }
        });

        //Get All Available Items
        MyHttpUtil.getWithToken(MyUrlConfig.supplier + "?supplierName=", "GET", new MyHttpCallbackUtil() {
            @Override
            public void onSuccess(String data) {
                Response<List<Supplier>> result = MyJsonUtil.fromJson(data, new TypeToken<Response<List<Supplier>>>() {
                }.getType());
                if (result != null) {
                    supplierList = result.getData();
                    MyAdapter<Supplier> adapter = new MyAdapter<Supplier>(context, supplierList, R.layout.item_items) {
                        @Override
                        public void convert(ViewHolder helper, Supplier supplier, int position) {
                            helper.setText(R.id.tv_itemName, supplier.getName());
                        }
                    };
                    listView.setAdapter(adapter);
                }
            }

            @Override
            public void onFailure(String data) {
                FailureResponse<String> result = MyJsonUtil.fromJson(data, new TypeToken<FailureResponse<String>>() {
                }.getType());
                MyToastUtil.show(context, result.getMsg());
            }
        });

        /**
         * Search for items available
         */
        btn_search.setOnClickListener(v -> {
            String supplierName = edit_search.getText().toString();

            //get all item available
            MyHttpUtil.getWithToken(MyUrlConfig.supplier + "?supplierName=" + supplierName, "GET", new MyHttpCallbackUtil() {
                @Override
                public void onSuccess(String data) {
                    Response<List<Supplier>> result = MyJsonUtil.fromJson(data, new TypeToken<Response<List<Supplier>>>() {
                    }.getType());
                    if (result != null) {
                        supplierList = result.getData();
                        MyAdapter<Supplier> adapter = new MyAdapter<Supplier>(context, supplierList, R.layout.item_items) {
                            @Override
                            public void convert(ViewHolder helper, Supplier supplier, int position) {
                                helper.setText(R.id.tv_itemName, supplier.getName());
                            }
                        };
                        listView.setAdapter(adapter);
                    }
                }

                @Override
                public void onFailure(String data) {
                    FailureResponse<String> result = MyJsonUtil.fromJson(data, new TypeToken<FailureResponse<String>>() {
                    }.getType());
                    MyToastUtil.show(context, result.getMsg());
                }
            });
        });
    }

    /**
     * CityDat callback interface (need override)
     */
    public interface Callback {
        void onCall(Supplier supplier);
    }
}
