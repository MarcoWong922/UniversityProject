/*
 * NTU Wenjia Geng (c) All rights reserved
 * None of this code can be reproduced or partly re-used without the permission
 * from Wenjia Geng (wenjia.geng2020@my.ntu.ac.uk).
 */
package com.ffsmartclient.ui.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;

import com.ffsmartclient.model.Inventory;
import com.ffsmartclient.R;
import com.ffsmartclient.utils.httputils.FailureResponse;
import com.ffsmartclient.utils.httputils.MyHttpCallbackUtil;
import com.ffsmartclient.utils.httputils.MyHttpUtil;
import com.ffsmartclient.utils.httputils.MyUrlConfig;
import com.ffsmartclient.utils.httputils.Response;
import com.ffsmartclient.utils.MyJsonUtil;
import com.ffsmartclient.utils.MyToastUtil;
import com.ffsmartclient.ui.adapter.MyAdapter;
import com.ffsmartclient.ui.adapter.ViewHolder;
import com.google.gson.reflect.TypeToken;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

/**
 * Inventory Item Page Controller
 *
 * @author Wenjia Geng
 */

public class InventoryActivity extends AppCompatActivity {

    private Activity context;
    private EditText edit_itemName;
    private EditText edit_maxQuantity;
    private EditText edit_minQuantity;
    private EditText edit_fromDate;
    private EditText edit_toDate;
    private ListView listView;


    private List<Inventory> items = new ArrayList<>();

    private MyAdapter<Inventory> myAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);
        context = this;

        ImageView iv_back;
        Button btn_search;
        Button btn_reset;
        Button btn_clearExpired;
        iv_back = findViewById(R.id.iv_back);
        edit_itemName = findViewById(R.id.edit_itemName);
        edit_maxQuantity = findViewById(R.id.edit_maxQuantity);
        edit_minQuantity = findViewById(R.id.edit_minQuantity);
        edit_fromDate = findViewById(R.id.edit_fromDate);
        edit_toDate = findViewById(R.id.edit_toDate);
        btn_search = findViewById(R.id.btn_search);
        btn_search.setBackgroundColor(Color.parseColor("#a00000"));

        listView = findViewById(R.id.listView);

        btn_reset = findViewById(R.id.btn_reset);
        btn_clearExpired = findViewById(R.id.btn_clearExpired);

        /**
         * Display the All Inventory Items in the ListView
         */
        myAdapter = new MyAdapter<Inventory>(context, items, R.layout.item_normal_inventory) {
            @Override
            public void convert(ViewHolder helper, Inventory inventory, int position) {
                helper.setText(R.id.tv_inventoryItemName, inventory.getItemName());
                helper.setText(R.id.tv_expiryDate, inventory.getExpiryDate());
                helper.setText(R.id.tv_quantity, " " + inventory.getQuantity());

                /**
                 * Check the inventory details
                 */
                helper.getView(R.id.iv_infoInventoryItem).setOnClickListener(v -> {
                    Intent intent = new Intent();
                    intent.setClass(context, InventoryItemDetailsActivity.class);
                    intent.putExtra("Inventory_id", inventory.getId());//store the trip id within the "Inventory_id" key
                    startActivity(intent);
                });
            }
        };
        listView.setAdapter(myAdapter);

        loadInventoryList(myAdapter);

        btn_search.setOnClickListener(v -> searchInventoryItem());

        //Rest Button
        btn_reset.setOnClickListener(v -> {
            loadInventoryList(myAdapter);
            resetAddItem();
        });

        //Clear Expired Items Button
        btn_clearExpired.setOnClickListener(v ->
            /**
             * Send a DELETE method "Clear Expired Inventory Items" request to the server
             */
            MyHttpUtil.getWithToken(MyUrlConfig.inventory + "/expired-items", "DELETE", new MyHttpCallbackUtil() {
                @Override
                public void onSuccess(String data) {
                    MyToastUtil.show(context, "Success");
                    loadInventoryList(myAdapter);
                }

                @Override
                public void onFailure(String data) {
                    MyToastUtil.show(context, "Success");
                }
            })
        );

        iv_back.setOnClickListener(v -> finish());
    }

    /**
     * pdate inventory item list
     */
    @Override
    protected void onResume() {
        super.onResume();
        loadInventoryList(myAdapter);
    }

    /**
     * Search Inventory Items
     */
    private void searchInventoryItem() {
        String itemName = edit_itemName.getText().toString();
        String maxQuantityStr = !"".equals(edit_maxQuantity.getText().toString().trim()) ? edit_maxQuantity.getText().toString() : "100000";
        String minQuantityStr = !"".equals(edit_minQuantity.getText().toString().trim()) ? edit_minQuantity.getText().toString() : "0";
        String fromDate = !"".equals(edit_fromDate.getText().toString().trim()) ? edit_fromDate.getText().toString() : "2020-01-01";
        String toDate = !"".equals(edit_toDate.getText().toString().trim()) ? edit_toDate.getText().toString() : "2030-01-01";

        //Check if the item name is empty
        if ("".equals(itemName.trim())) {
            MyToastUtil.show(context, "Please enter the item name");
            return;
        }

        //Check if the quantity is empty
        int maxQuantity;
        int minQuantity;
        boolean maxCheckPass = Pattern.matches("^\\d+$", maxQuantityStr);
        boolean minCheckPass = Pattern.matches("^\\d+$", minQuantityStr);
        //Check the age contains only digits
        if (!maxCheckPass && !minCheckPass) {
            MyToastUtil.show(context, "Quantity can only include digits");
            return;
        } else {
            maxQuantity = Integer.parseInt(maxQuantityStr);
            minQuantity = Integer.parseInt(minQuantityStr);
        }

        //check date
        //date format: year-month-day
        boolean fromDateCheckPass = Pattern.matches("^\\d{4}-(0[1-9]|1[0-2])-(0[1-9]|[12]\\d|3[01])$", fromDate);
        boolean toDateCheckPass = Pattern.matches("^\\d{4}-(0[1-9]|1[0-2])-(0[1-9]|[12]\\d|3[01])$", toDate);
        //Check the format of the date
        if (!fromDateCheckPass || !toDateCheckPass) {
            MyToastUtil.show(context, "Wrong Date Format");
            return;
        }

        /**
         * Send a GET method "get inventory items by conditions" request to the server
         */
        MyHttpUtil.getWithToken(MyUrlConfig.inventory + "?itemName=" + itemName + "&minQuantity=" + minQuantity + "&maxQuantity=" + maxQuantity + "&expiryDateFrom=" + fromDate + "&expiryDateTo=" + toDate, "GET", new MyHttpCallbackUtil() {
            @Override
            public void onSuccess(String data) {
                Response<List<Inventory>> result = MyJsonUtil.fromJson(data, new TypeToken<Response<List<Inventory>>>() {
                }.getType());
                if (result != null) {
                    items.clear();
                    items.addAll(result.getData());
                }
                myAdapter.notifyDataSetChanged();
            }

            @Override
            public void onFailure(String data) {
                FailureResponse<String> result = MyJsonUtil.fromJson(data, new TypeToken<FailureResponse<String>>() {
                }.getType());
                MyToastUtil.show(context, result.getMsg());
            }
        });
    }

    /**
     * Load Inventory Item List
     */
    private void loadInventoryList(MyAdapter<Inventory> myAdapter) {
        //Get All Available Inventory Items
        MyHttpUtil.getWithToken(MyUrlConfig.inventory, "GET", new MyHttpCallbackUtil() {
            @Override
            public void onSuccess(String data) {
                Response<List<Inventory>> result = MyJsonUtil.fromJson(data, new TypeToken<Response<List<Inventory>>>() {
                }.getType());
                if (result != null) {
                    items.clear();
                    items.addAll(result.getData());
                }
                myAdapter.notifyDataSetChanged();//Notify the adapter to display new data
                listView.setOnItemClickListener((adapterView, view, i, l) -> {
                    if (items != null && items.size() > i) {
                        ImageView infoButton = view.findViewById(R.id.iv_infoInventoryItem);
                        infoButton.setOnClickListener(v -> {
                            Inventory inventory = items.get(i);
                            Intent intent = new Intent();
                            intent.setClass(context, InventoryItemDetailsActivity.class);
                            intent.putExtra("Inventory_id", inventory.getId());//store the trip id within the "Inventory_id" key
                            startActivity(intent);
                        });
                    }
                });
            }

            @Override
            public void onFailure(String data) {
                FailureResponse<String> result = MyJsonUtil.fromJson(data, new TypeToken<FailureResponse<String>>() {
                }.getType());
                MyToastUtil.show(context, result.getMsg());
            }
        });
    }

    /**
     * Reset Search Components
     */
    private void resetAddItem() {
        edit_itemName.setText("");
        edit_minQuantity.setText("");
        edit_maxQuantity.setText("");
        edit_fromDate.setText("");
        edit_toDate.setText("");
    }
}