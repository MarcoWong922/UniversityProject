/*
 * NTU Wenjia Geng (c) All rights reserved
 * None of this code can be reproduced or partly re-used without the permission
 * from Wenjia Geng (wenjia.geng2020@my.ntu.ac.uk).
 */
package com.ffsmartclient.utils;

import java.util.logging.Logger;

/**
 * Output the information needed for debug to the console
 *
 * @author Wenjia Geng
 */
public class MyLogUtil {

    private MyLogUtil() {
        throw new IllegalStateException("MyLogUtil class");
    }

    public static void log(String message){
        Logger myLogger = Logger.getLogger("com.ffsmartclient");
        myLogger.info(message);
    }

}