/*
 * NTU Wenjia Geng (c) All rights reserved
 * None of this code can be reproduced or partly re-used without the permission
 * from Wenjia Geng (wenjia.geng2020@my.ntu.ac.uk).
 */
package com.ffsmartclient.ui.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.ListView;

import com.ffsmartclient.model.User;
import com.ffsmartclient.R;
import com.ffsmartclient.utils.httputils.FailureResponse;
import com.ffsmartclient.utils.httputils.MyHttpCallbackUtil;
import com.ffsmartclient.utils.httputils.MyHttpUtil;
import com.ffsmartclient.utils.httputils.MyUrlConfig;
import com.ffsmartclient.utils.httputils.Response;
import com.ffsmartclient.utils.MyJsonUtil;
import com.ffsmartclient.utils.MyToastUtil;
import com.ffsmartclient.ui.adapter.MyAdapter;
import com.ffsmartclient.ui.adapter.ViewHolder;
import com.google.gson.reflect.TypeToken;

/**
 * User Accounts Page Controller
 *
 * @author Wenjia Geng
 */

import java.util.List;

public class UserAccountActivity extends AppCompatActivity {

    private ListView listView;
    private List<User> users;

    private Activity context;

    private MyAdapter<User> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_account);
        context = this;

        ImageView iv_back;
        iv_back = findViewById(R.id.iv_back);
        listView = findViewById(R.id.listView);

        getAllUsers();

        //Back Button
        iv_back.setOnClickListener(v -> finish());
    }

    /**
     * Update users list
     */
    @Override
    protected void onResume() {
        super.onResume();
        getAllUsers();
    }

    /**
     * Get All orders request
     */
    private void getAllUsers() {
        /**
         * Send a GET method "get all users" request to the server
         */
        MyHttpUtil.getWithToken(MyUrlConfig.user, "GET", new MyHttpCallbackUtil() {
            @Override
            public void onSuccess(String data) {

                Response<List<User>> result = MyJsonUtil.fromJson(data, new TypeToken<Response<List<User>>>() {
                }.getType());
                if (result != null) {
                    users = result.getData();
                    /**
                     * Display the items that the supplier provided in a ListView
                     */
                    adapter = new MyAdapter<User>(context, users, R.layout.item_users) {
                        @Override
                        public void convert(ViewHolder helper, User user, int position) {

                            helper.setText(R.id.tv_firstName, user.getFirstName());
                            helper.setText(R.id.tv_lastName, user.getLastName());
                            int role = user.getRole();
                            String userRole;
                            if (role == 0) {
                                userRole = "Driver";
                            } else if (role == 1) {
                                userRole = "Chef";
                            } else {
                                userRole = "Head Chef";
                            }
                            helper.setText(R.id.tv_userRole, userRole);

                            helper.getView(R.id.iv_infoUser).setOnClickListener(v -> {
                                Intent intent = new Intent();
                                intent.setClass(context, UserManageActivity.class);
                                intent.putExtra("Manage_userId", user.getId());
                                startActivity(intent);
                            });
                        }
                    };
                    listView.setAdapter(adapter);
                }
            }

            @Override
            public void onFailure(String data) {
                FailureResponse<String> result = MyJsonUtil.fromJson(data, new TypeToken<FailureResponse<String>>() {
                }.getType());
                MyToastUtil.show(context, result.getMsg());
            }
        });
    }


}