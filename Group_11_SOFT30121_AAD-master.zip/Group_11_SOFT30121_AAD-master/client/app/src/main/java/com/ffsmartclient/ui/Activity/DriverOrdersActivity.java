/*
 * NTU Wenjia Geng (c) All rights reserved
 * None of this code can be reproduced or partly re-used without the permission
 * from Wenjia Geng (wenjia.geng2020@my.ntu.ac.uk).
 */
package com.ffsmartclient.ui.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.ListView;

import com.ffsmartclient.model.Order;
import com.ffsmartclient.R;
import com.ffsmartclient.utils.httputils.FailureResponse;
import com.ffsmartclient.utils.httputils.MyHttpCallbackUtil;
import com.ffsmartclient.utils.httputils.MyHttpUtil;
import com.ffsmartclient.utils.httputils.MyUrlConfig;
import com.ffsmartclient.utils.httputils.Response;
import com.ffsmartclient.utils.MyJsonUtil;
import com.ffsmartclient.utils.MyToastUtil;
import com.ffsmartclient.ui.adapter.MyAdapter;
import com.ffsmartclient.ui.adapter.ViewHolder;
import com.google.gson.reflect.TypeToken;

import java.util.List;

/**
 * Driver Orders Page Controller
 *
 * @author Wenjia Geng
 */

public class DriverOrdersActivity extends AppCompatActivity {

    private ListView listView;
    private List<Order> orders;

    private Activity context;
    private MyAdapter<Order> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_driver_orders);
        context = this;

        ImageView iv_back;
        iv_back = findViewById(R.id.iv_back);
        listView = findViewById(R.id.listView);

        getAllOrders();

        //Back Button
        iv_back.setOnClickListener(v -> finish());
    }

    /**
     * Update orders list
     */
    @Override
    protected void onResume() {
        super.onResume();
        getAllOrders();
    }

    /**
     * Get All orders
     */
    private void getAllOrders() {
        /**
         * Send a GET method "get all order placed" request to the server
         */
        MyHttpUtil.getWithToken(MyUrlConfig.order + "/approved", "GET", new MyHttpCallbackUtil() {
            @Override
            public void onSuccess(String data) {
                Response<List<Order>> result = MyJsonUtil.fromJson(data, new TypeToken<Response<List<Order>>>() {
                }.getType());
                if (result != null) {
                    orders = result.getData();
                    /**
                     * Display the all orders in a ListView
                     */
                    adapter = new MyAdapter<Order>(context, orders, R.layout.item_driver_orders) {
                        @Override
                        public void convert(ViewHolder helper, Order order, int position) {
                            //0-ready
                            //1-submitted
                            //2-dispatched
                            //3- delivered
                            helper.setText(R.id.tv_orderId, order.getId());
                            helper.setText(R.id.tv_deliveryDate, order.getDeliveryDate());
                            helper.setText(R.id.tv_orderPlaceDate, order.getPlacedDate());

                            /**
                             * Check the order details
                             */
                            helper.getView(R.id.iv_infoOrder).setOnClickListener(v -> {
                                Intent intent = new Intent();
                                intent.setClass(context, DriverOrderDetailsActivity.class);
                                intent.putExtra("Order_id", order.getId());
                                startActivity(intent);
                            });
                        }
                    };
                    listView.setAdapter(adapter);
                }
            }

            @Override
            public void onFailure(String data) {
                FailureResponse<String> result = MyJsonUtil.fromJson(data, new TypeToken<FailureResponse<String>>() {
                }.getType());
                MyToastUtil.show(context, result.getMsg());
            }
        });

    }

}