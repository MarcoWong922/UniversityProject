/*
 * NTU Wenjia Geng (c) All rights reserved
 * None of this code can be reproduced or partly re-used without the permission
 * from Wenjia Geng (wenjia.geng2020@my.ntu.ac.uk).
 */
package com.ffsmartclient.utils;

import android.content.Context;
import android.widget.Toast;

/**
 * For displaying a short reminder message on the screen
 *
 * @author Wenjia Geng
 */
public class MyToastUtil {

    private MyToastUtil() {
        throw new IllegalStateException("MyToastUtil class");
    }

    /**
     * Display a toast message on the screen
     */
    public static void show(Context context, String msg){
        Toast.makeText(context, msg, Toast.LENGTH_SHORT).show();
    }

}