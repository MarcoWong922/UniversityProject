/*
 * NTU Wenjia Geng (c) All rights reserved
 * None of this code can be reproduced or partly re-used without the permission
 * from Wenjia Geng (wenjia.geng2020@my.ntu.ac.uk).
 */
package com.ffsmartclient.utils;

import java.lang.reflect.Type;

import com.google.gson.Gson;

/**
 * Serialize java objects to json format strings and deserialize json format strings to java objects
 *
 * @author Wenjia Geng
 */

public class MyJsonUtil {

    public MyJsonUtil() {
        // Do nothing because of testing.
    }

    /**
     * Convert a java object to the string in JSON format
     * @param object The java object to be serialized
     * @return string in JSON format
     */
    public static String toJson(Object object) {
        String result = null;
        try {
            Gson gson = new Gson();
            result = gson.toJson(object);
        }catch (Exception e){
            e.printStackTrace();
        }
        return result;
    }


    /**
     * Convert JSON to all type object
     * @param str String data in JSON format to be deserialized
     * @param type all types
     * @param <T> placeholder for the type
     * @return an object with the specified type
     */
    public static <T> T fromJson(String str, Type type) {
        T t = null;
        try {
            Gson gson = new Gson();
            t = gson.fromJson(str, type);
        }catch (Exception e){
            e.printStackTrace();
        }
        return t;
    }

    /**
     * Convert JSON to generic type object
     * @param str String data in JSON format to be deserialized
     * @param clazz the specified class
     * @param <T> placeholder for the class's type
     * @return an object with the specified class's type
     */
    public static <T> T fromJson(String str, Class<T> clazz) {
        T t = null;
        try {
            Gson gson = new Gson();
            t = gson.fromJson(str, clazz);
        }catch (Exception e){
            e.printStackTrace();
        }
        return t;
    }

}
