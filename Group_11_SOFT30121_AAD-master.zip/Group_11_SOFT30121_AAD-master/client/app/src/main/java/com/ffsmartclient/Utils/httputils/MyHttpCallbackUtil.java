/*
 * NTU Wenjia Geng (c) All rights reserved
 * None of this code can be reproduced or partly re-used without the permission
 * from Wenjia Geng (wenjia.geng2020@my.ntu.ac.uk).
 */
package com.ffsmartclient.utils.httputils;

/**
 * Implement callbacks when sending HTTP requests
 *
 * @author Wenjia Geng
 */
public interface MyHttpCallbackUtil {

    void onSuccess(String data);

    void onFailure(String data);
}
