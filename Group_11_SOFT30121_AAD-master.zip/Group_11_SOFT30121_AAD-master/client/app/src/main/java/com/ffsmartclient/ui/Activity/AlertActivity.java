/*
 * NTU Wenjia Geng (c) All rights reserved
 * None of this code can be reproduced or partly re-used without the permission
 * from Wenjia Geng (wenjia.geng2020@my.ntu.ac.uk).
 */
package com.ffsmartclient.ui.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;

import android.graphics.Color;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;

import com.blankj.utilcode.util.SPUtils;
import com.ffsmartclient.common.LoginSession;
import com.ffsmartclient.model.Alert;

import com.ffsmartclient.R;
import com.ffsmartclient.utils.httputils.FailureResponse;
import com.ffsmartclient.utils.httputils.MyHttpCallbackUtil;
import com.ffsmartclient.utils.httputils.MyHttpUtil;
import com.ffsmartclient.utils.httputils.MyUrlConfig;
import com.ffsmartclient.utils.httputils.Response;
import com.ffsmartclient.utils.MyJsonUtil;
import com.ffsmartclient.utils.MyToastUtil;
import com.ffsmartclient.ui.adapter.MyAdapter;
import com.ffsmartclient.ui.adapter.ViewHolder;
import com.google.gson.reflect.TypeToken;

import java.text.SimpleDateFormat;

import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * System Alert Page Controller
 *
 * @author Wenjia Geng
 */

public class AlertActivity extends AppCompatActivity {

    String template = "yyyy-MM-dd";
    Locale locale = Locale.UK;

    private ListView listView;
    private List<Alert> alerts;
    private Button btn_clearAll;

    private Activity context;
    private MyAdapter<Alert> adapter;

    private static final String ALERT_KET = "SystemAlert";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_alert);
        context = this;

        ImageView iv_back;
        iv_back = findViewById(R.id.iv_back);
        listView = findViewById(R.id.listView);
        btn_clearAll = findViewById(R.id.btn_clearAll);
        btn_clearAll.setBackgroundColor(Color.parseColor("#a00000"));

        /**
         * Send a GET method "get all alerts" request to the server
         */
        MyHttpUtil.getWithToken(MyUrlConfig.alert, "GET", new MyHttpCallbackUtil() {
            @Override
            public void onSuccess(String data) {
                Response<List<Alert>> result = MyJsonUtil.fromJson(data, new TypeToken<Response<List<Alert>>>() {
                }.getType());
                if (result != null) {
                    alerts = result.getData();
                    //Get old alerts and combine with new alerts
                    String alertJson = SPUtils.getInstance().getString(LoginSession.getUid() + ALERT_KET);
                    if (!"".equals(alertJson)) {
                        List<Alert> oldAlertList = MyJsonUtil.fromJson(alertJson, new TypeToken<List<Alert>>() {
                        }.getType());
                        alerts.addAll(oldAlertList);
                    }
                    SPUtils.getInstance().put(LoginSession.getUid() + ALERT_KET, MyJsonUtil.toJson(alerts));

                    displayAlert();

                    //Clear all cached alerts Button
                    btn_clearAll.setOnClickListener(v -> {
                        SPUtils.getInstance().put(LoginSession.getUid() + ALERT_KET, "");
                        alerts.clear();
                        adapter.notifyDataSetChanged();
                    });
                }
            }

            @Override
            public void onFailure(String data) {
                FailureResponse<String> result = MyJsonUtil.fromJson(data, new TypeToken<FailureResponse<String>>() {
                }.getType());
                MyToastUtil.show(context, result.getMsg());
            }
        });

        //Back Button
        iv_back.setOnClickListener(v -> finish());
    }

    /**
     * Display all alerts in the ListView
     */
    private void displayAlert() {
        adapter = new MyAdapter<Alert>(context, alerts, R.layout.item_alerts) {
            @Override
            public void convert(ViewHolder helper, Alert alert, int position) {
                String alertType;
                int alertTypeInt = alert.getAlertCode();
                if (alertTypeInt == 0) {
                    alertType = "Expired Items";
                } else if (alertTypeInt == 1) {
                    alertType = "Low Quantity Items";
                } else if (alertTypeInt == 2) {
                    alertType = "Order Ready";
                } else if (alertTypeInt == 3) {
                    alertType = "Order Placed";
                } else if (alertTypeInt == 4) {
                    alertType = "Order Delivered";
                } else {
                    alertType = "Order Check Successful";
                }
                helper.setText(R.id.tv_alertType, alertType);
                helper.setText(R.id.tv_alertDescription, alert.getMessage());

                //Time convert into to minutes/hours/days
                int oneHour = 60;
                int oneDay = 1440;
                int oneWeek = 10080;
                Date inputDateObj = alert.getTimestamp();
                Date now = new Date();
                long durationInMillis = now.getTime() - inputDateObj.getTime();
                long durationInMinutes = durationInMillis / (1000 * 60);
                if (durationInMinutes <= oneHour) {
                    helper.setText(R.id.tv_alertDate, durationInMinutes + "Mins");
                } else if (durationInMinutes < oneDay) {
                    long durationInHours = durationInMinutes / 60;
                    helper.setText(R.id.tv_alertDate, durationInHours + "Hrs");
                } else if (durationInMinutes < oneWeek) {
                    long durationInDays = durationInMinutes / (60 * 24);
                    helper.setText(R.id.tv_alertDate, durationInDays + "Days");
                } else {
                    SimpleDateFormat format2 = new SimpleDateFormat(template, locale);
                    String formattedDate = format2.format(inputDateObj);
                    helper.setText(R.id.tv_alertDate, formattedDate + "");
                }
            }
        };
        listView.setAdapter(adapter);
    }
}