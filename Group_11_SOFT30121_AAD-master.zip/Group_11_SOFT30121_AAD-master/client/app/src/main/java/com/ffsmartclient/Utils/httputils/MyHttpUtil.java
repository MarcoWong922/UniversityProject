/*
 * NTU Wenjia Geng (c) All rights reserved
 * None of this code can be reproduced or partly re-used without the permission
 * from Wenjia Geng (wenjia.geng2020@my.ntu.ac.uk).
 */
package com.ffsmartclient.utils.httputils;

import android.os.Handler;
import android.os.Looper;

import com.blankj.utilcode.util.SPUtils;
import com.ffsmartclient.common.LoginSession;
import com.ffsmartclient.utils.MyJsonUtil;
import com.ffsmartclient.utils.MyLogUtil;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * Send GET, DELETE, POST, and PUT requests to the server and read the response
 *
 * @author Wenjia Geng
 */

public class MyHttpUtil {

    private MyHttpUtil() {
        throw new IllegalStateException("MyHttpUtil class");
    }

    private static final String ACTION_GET_REQUEST_URL = "GET Request URL: ";
    private static final String ACTION_GET_RESPONSE_CODE = "GET Response code: ";

    private static final String ACTION_GET_SUCCESS_RESPONSE = "GET Success Response JSON: ";
    private static final String ACTION_GET_ERROR_RESPONSE = "GET Error Response JSON: ";

    private static final String APP_JSON = "application/json";

    private static final String AUTHORIZATION = "Authorization";
    private static final String BEARER = "Bearer ";



    public static void getWithToken(String apiUrl, String method, MyHttpCallbackUtil callback) {
        MyLogUtil.log(ACTION_GET_REQUEST_URL + apiUrl);
        new Thread(() -> {
            HttpURLConnection connection = null;
            StringBuilder stringBuilder = null;
            int responseCode = 0;
            URL url = null;
            try {
                url = new URL(apiUrl);
                connection = (HttpURLConnection) url.openConnection();
                stringBuilder = new StringBuilder();
                connection.setRequestMethod(method);
                String token = SPUtils.getInstance().getString(LoginSession.getUid());
                connection.setRequestProperty(AUTHORIZATION, BEARER + token);
                connection.connect();
                responseCode = connection.getResponseCode();
                MyLogUtil.log(ACTION_GET_RESPONSE_CODE + responseCode);
            } catch (IOException e) {
                e.printStackTrace();
            }

            try (BufferedReader reader = new BufferedReader(new InputStreamReader(responseCode <= 300 ? connection.getInputStream() : connection.getErrorStream()))) {
                //Retrieve the result of the http request and pass it into the StringBuilder
                String line = reader.readLine();
                while (line != null) {
                    stringBuilder.append(line + "\r\n");
                    line = reader.readLine();
                }
                String json = stringBuilder.toString();
                if (responseCode <= 300) {
                    MyLogUtil.log(ACTION_GET_SUCCESS_RESPONSE + json);
                    new Handler(Looper.getMainLooper()).post(() -> callback.onSuccess(json));
                } else {
                    MyLogUtil.log(ACTION_GET_ERROR_RESPONSE + json);
                    new Handler(Looper.getMainLooper()).post(() -> callback.onFailure(json));
                }
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                try {
                    if (connection != null) {
                        connection.disconnect();
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }).start();
    }

    public static void getWithTokenInIS(String apiUrl, String method, MyHttpCallbackPdfUtil callback) {
        MyLogUtil.log(ACTION_GET_REQUEST_URL + apiUrl);
        /**
         * Create a new thread
         * the main Android thread is used to implement ui so it cannot make http requests
         */
        new Thread(() -> {

            HttpURLConnection connection = null;
            int responseCode = 0;
            URL url = null;
            try {
                url = new URL(apiUrl);
                connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod(method);
                String token = SPUtils.getInstance().getString(LoginSession.getUid());
                connection.setRequestProperty(AUTHORIZATION, BEARER + token);
                connection.connect();
                responseCode = connection.getResponseCode();
                MyLogUtil.log(ACTION_GET_RESPONSE_CODE + responseCode);
            } catch (IOException e) {
                e.printStackTrace();
            }

            try  {
                BufferedInputStream inputStream = new BufferedInputStream(responseCode <= 300 ? connection.getInputStream() : connection.getErrorStream());
                if (responseCode <= 300) {
                    new Handler(Looper.getMainLooper()).post(() -> callback.onSuccess(inputStream));
                } else {
                    new Handler(Looper.getMainLooper()).post(() -> callback.onFailure("Read PDF Failed"));
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }).start();
    }

    public static void post(String apiUrl, Object obj, String method, MyHttpCallbackUtil callback) {
        String param = MyJsonUtil.toJson(obj);
        MyLogUtil.log("POST Request URL: " + apiUrl);
        MyLogUtil.log("POST Request object: " + param);

        new Thread(() -> {
            HttpURLConnection connection = null;
            OutputStream outputStream = null;
            StringBuilder stringBuilder = null;
            int responseCode = 0;
            URL url = null;
            try {
                url = new URL(apiUrl);
                connection = (HttpURLConnection) url.openConnection();
                stringBuilder = new StringBuilder();
                connection.setRequestMethod(method);

                //Accept response in JSON format
                connection.setRequestProperty("Accept", APP_JSON);
                //Sending request in JSON format
                connection.setRequestProperty("Content-Type", APP_JSON);
                connection.setDoOutput(true);
                connection.setDoInput(true);

                connection.connect();

                outputStream = connection.getOutputStream();
                //Write request body data into output stream
                outputStream.write(param.getBytes());
                //Send the output stream data from the buffer
                outputStream.flush();

                responseCode = connection.getResponseCode();
                MyLogUtil.log(ACTION_GET_RESPONSE_CODE + responseCode);
            } catch (IOException e) {
                e.printStackTrace();
            }

            try (BufferedReader reader = new BufferedReader(new InputStreamReader(responseCode <= 300 ? connection.getInputStream() : connection.getErrorStream()))) {
                //Retrieve the result of the http request and pass it into the StringBuilder
                String line = reader.readLine();
                while (line != null) {
                    stringBuilder.append(line + "\r\n");
                    line = reader.readLine();
                }
                String json = stringBuilder.toString();
                if (responseCode <= 300) {
                    MyLogUtil.log(ACTION_GET_SUCCESS_RESPONSE + json);
                    new Handler(Looper.getMainLooper()).post(() -> callback.onSuccess(json));
                } else {
                    MyLogUtil.log(ACTION_GET_ERROR_RESPONSE + json);
                    new Handler(Looper.getMainLooper()).post(() -> callback.onFailure(json));
                }
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                try {
                    if (connection != null) {
                        connection.disconnect();
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }).start();
    }

    public static void postWithToken(String apiUrl, Object obj, String method, MyHttpCallbackUtil callback) {
        String param = MyJsonUtil.toJson(obj);
        MyLogUtil.log("POST Request URL: " + apiUrl);
        MyLogUtil.log("POST Request object: " + param);

        new Thread(() -> {
            HttpURLConnection connection = null;
            OutputStream outputStream = null;
            StringBuilder stringBuilder = null;
            int responseCode = 0;
            URL url = null;
            try {
                url = new URL(apiUrl);
                connection = (HttpURLConnection) url.openConnection();
                stringBuilder = new StringBuilder();
                connection.setRequestMethod(method);
                String token = SPUtils.getInstance().getString(LoginSession.getUid());
                connection.setRequestProperty(AUTHORIZATION, BEARER + token);

                //Accept response in JSON format
                connection.setRequestProperty("Accept", APP_JSON);
                //Sending request in JSON format
                connection.setRequestProperty("Content-Type", APP_JSON);
                connection.setDoOutput(true);
                connection.setDoInput(true);

                connection.connect();

                outputStream = connection.getOutputStream();
                //Write request body data into output stream
                outputStream.write(param.getBytes());
                //Send the output stream data from the buffer
                outputStream.flush();

                responseCode = connection.getResponseCode();
                MyLogUtil.log(ACTION_GET_RESPONSE_CODE + responseCode);
            } catch (IOException e) {
                e.printStackTrace();
            }

            try (BufferedReader reader = new BufferedReader(new InputStreamReader(responseCode <= 300 ? connection.getInputStream() : connection.getErrorStream()))) {
                //Retrieve the result of the http request and pass it into the StringBuilder
                String line = reader.readLine();
                while (line != null) {
                    stringBuilder.append(line + "\r\n");
                    line = reader.readLine();
                }
                String json = stringBuilder.toString();
                if (responseCode <= 300) {
                    MyLogUtil.log(ACTION_GET_SUCCESS_RESPONSE + json);
                    new Handler(Looper.getMainLooper()).post(() -> callback.onSuccess(json));
                } else {
                    MyLogUtil.log(ACTION_GET_ERROR_RESPONSE + json);
                    new Handler(Looper.getMainLooper()).post(() -> callback.onFailure(json));
                }
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                try {
                    if (connection != null) {
                        connection.disconnect();
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }).start();
    }
}