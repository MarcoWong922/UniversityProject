/*
 * NTU Wenjia Geng (c) All rights reserved
 * None of this code can be reproduced or partly re-used without the permission
 * from Wenjia Geng (wenjia.geng2020@my.ntu.ac.uk).
 */
package com.ffsmartclient.ui.activity;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Base64;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.resource.bitmap.CircleCrop;
import com.ffsmartclient.common.LoginSession;
import com.ffsmartclient.model.User;
import com.ffsmartclient.R;
import com.ffsmartclient.utils.httputils.FailureResponse;
import com.ffsmartclient.utils.httputils.MyHttpCallbackUtil;
import com.ffsmartclient.utils.httputils.MyHttpUtil;
import com.ffsmartclient.utils.httputils.MyUrlConfig;
import com.ffsmartclient.utils.httputils.Response;
import com.ffsmartclient.utils.MyJsonUtil;
import com.ffsmartclient.utils.MyLogUtil;
import com.ffsmartclient.utils.MyToastUtil;
import com.google.gson.reflect.TypeToken;

import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.util.regex.Pattern;

/**
 * My Profile Page Controller
 *
 * @author Wenjia Geng
 */

public class MyProfileActivity extends AppCompatActivity {

    private EditText edit_firstName;
    private EditText edit_lastName;
    private EditText edit_email;
    private EditText edit_password;
    private EditText edit_confirm_password;

    private User user;
    private Activity context;
    private String imgBase64;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_profile);
        context = this;

        Button btn_upload;
        Button btn_profileUpdate;
        Button btn_userDelete;
        TextView tv_userRole;
        ImageView iv_back;
        TextView tv_userId;

        iv_back = findViewById(R.id.iv_back);
        tv_userId = findViewById(R.id.tv_userId);
        btn_upload = findViewById(R.id.btn_upload);
        tv_userRole = findViewById(R.id.tv_userRole);
        edit_firstName = findViewById(R.id.edit_firstName);
        edit_lastName = findViewById(R.id.edit_lastName);
        edit_email = findViewById(R.id.edit_email);
        edit_password = findViewById(R.id.edit_password);
        edit_confirm_password = findViewById(R.id.edit_confirm_password);
        btn_userDelete = findViewById(R.id.btn_userDelete);
        btn_userDelete.setBackgroundColor(Color.parseColor("#a00000"));
        btn_profileUpdate = findViewById(R.id.btn_profileUpdate);

        user = LoginSession.getUser();
        String userId = "User ID: " + user.getId();
        tv_userId.setText(userId);

        Bitmap bitmap;
        try {
            byte[] bytes = Base64.decode(user.getAvatar(), Base64.DEFAULT);
            bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
        } catch (Exception e) {
            bitmap = null;
        }
        Glide.with(this)
                .load(bitmap)
                .error(R.drawable.avatar)
                .transform(new CircleCrop())
                .into((ImageView) findViewById(R.id.iv_avatar));

        //assign role value
        int role = user.getRole();
        String userRole;
        if (role == 0) {
            userRole = "Role: Driver";
        } else if (role == 1) {
            userRole = "Role: Chef";
        } else {
            userRole = "Role: Head Chef";
        }
        tv_userRole.setText(userRole);
        edit_firstName.setText(user.getFirstName());
        edit_lastName.setText(user.getLastName());
        edit_email.setText(user.getEmail());

        //Upload Avatar Button
        btn_upload.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_PICK);
            intent.setDataAndType(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, "image/*");
            launcher.launch(intent);
        });

        //Update profile
        btn_profileUpdate.setOnClickListener(v -> updateProfile());

        //Delete user account
        btn_userDelete.setOnClickListener(v ->
                /**
                 * Send a DELETE method "Delete User Account" request to the server
                 */
                MyHttpUtil.postWithToken(MyUrlConfig.user + "/me", user, "DELETE", new MyHttpCallbackUtil() {
                    @Override
                    public void onSuccess(String data) {
                        MyToastUtil.show(context, "Success");
                        LoginSession.logout();
                        Intent intent = new Intent();
                        intent.setClass(context, LoginActivity.class);
                        startActivity(intent);
                        context.finish();
                    }

                    @Override
                    public void onFailure(String data) {
                        MyToastUtil.show(context, "Failed");
                    }
                })
        );

        //Back Button
        iv_back.setOnClickListener(v -> finish());
    }

    /**
     * Updates Profile
     */
    private void updateProfile() {
        String firstName = edit_firstName.getText().toString();
        String lastName = edit_lastName.getText().toString();
        String email = edit_email.getText().toString();
        String password = edit_password.getText().toString();
        String cPassword = edit_confirm_password.getText().toString();

        //Check if the username is empty
        if ("".equals(firstName.trim())) {
            MyToastUtil.show(context, "Please enter your first name");
            return;
        } else if ("".equals(lastName.trim())) {
            MyToastUtil.show(context, "Please enter your last name");
            return;
        }

        //Check the format of the Email
        boolean emailCheckPass = Pattern.matches("^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,6}$", email);
        if (!emailCheckPass) {
            MyToastUtil.show(context, "Wrong Email Format");
            return;
        }

        boolean passwordCheckPass = Pattern.matches("^(?!\\d+$)(?![a-zA-Z]+$)[0-9A-Za-z]{6,10}$", password);
        if (!"".equals(password.trim()) || !"".equals(cPassword.trim())) {
            if (!passwordCheckPass) {
                MyToastUtil.show(context, "Wrong Password Format");
                return;
            }
            //Check if the password entered matched
            if (!password.equals(cPassword)) {
                MyToastUtil.show(context, "The password doesn't match");
                return;
            }
            user.setPassword(password);
        } else {
            user.setPassword(null);
        }

        //Create a new user object
        user.setFirstName(firstName);
        user.setLastName(lastName);
        user.setEmail(email);
        user.setAvatar(imgBase64);

        /**
         * Send a PUT method "update user profile" request to the server
         */
        MyHttpUtil.postWithToken(MyUrlConfig.user + "/me", user, "PUT", new MyHttpCallbackUtil() {
            @Override
            public void onSuccess(String data) {
                Response<User> result = MyJsonUtil.fromJson(data, new TypeToken<Response<User>>() {
                }.getType());
                MyToastUtil.show(context, result.getMsg());
                User updatedUser = result.getData();
                LoginSession.setUser(updatedUser);
            }

            @Override
            public void onFailure(String data) {
                FailureResponse<String> result = MyJsonUtil.fromJson(data, new TypeToken<FailureResponse<String>>() {
                }.getType());
                MyToastUtil.show(context, result.getMsg());
            }
        });
    }

    /**
     * Call back method get the image
     */
    private final ActivityResultLauncher<Intent> launcher = registerForActivityResult(
        new ActivityResultContracts.StartActivityForResult(), result -> {
            if (result.getResultCode() == Activity.RESULT_OK) {
                Intent data = result.getData();
                MyLogUtil.log("Get Avatar Intent: " + data.toString());
                try {
                    Uri uri = data.getData();
                    Bitmap bitmap = BitmapFactory.decodeStream(context.getContentResolver().openInputStream(uri));

                    Glide.with(context)
                            .load(bitmap)
                            .error(R.drawable.avatar)
                            .transform(new CircleCrop())
                            .into((ImageView) findViewById(R.id.iv_avatar));

                    ByteArrayOutputStream out = new ByteArrayOutputStream();
                    bitmap.compress(Bitmap.CompressFormat.JPEG, 50, out);
                    byte[] array = out.toByteArray();
                    imgBase64 = Base64.encodeToString(array, Base64.DEFAULT);

                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                }
            }
        });
}