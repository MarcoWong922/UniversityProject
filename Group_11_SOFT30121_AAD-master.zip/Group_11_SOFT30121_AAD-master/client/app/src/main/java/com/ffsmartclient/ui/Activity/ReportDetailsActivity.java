/*
 * NTU Wenjia Geng (c) All rights reserved
 * None of this code can be reproduced or partly re-used without the permission
 * from Wenjia Geng (wenjia.geng2020@my.ntu.ac.uk).
 */
package com.ffsmartclient.ui.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ImageView;

import com.ffsmartclient.R;
import com.ffsmartclient.utils.httputils.FailureResponse;
import com.ffsmartclient.utils.httputils.MyHttpCallbackPdfUtil;
import com.ffsmartclient.utils.httputils.MyHttpUtil;
import com.ffsmartclient.utils.httputils.MyUrlConfig;
import com.ffsmartclient.utils.MyJsonUtil;
import com.ffsmartclient.utils.MyToastUtil;

import com.github.barteksc.pdfviewer.PDFView;
import com.google.gson.reflect.TypeToken;

import java.io.BufferedInputStream;
import java.io.InputStream;

/**
 * Report Details Page Controller
 *
 * @author Wenjia Geng
 */

public class ReportDetailsActivity extends AppCompatActivity {

    private PDFView pdfView;
    private Activity context;

    private InputStream inputStream;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_report_details);
        context = this;

        String report_Name;

        ImageView iv_back;
        pdfView = findViewById(R.id.pv_reportDetails);
        iv_back = findViewById(R.id.iv_back);

        //Get the inventory id of the inventory object selected in the previous page
        report_Name = getIntent().getStringExtra("Report_Name");

        /**
         * Send a GET method "get all reports" request to the server
         */
        MyHttpUtil.getWithTokenInIS(MyUrlConfig.report + "/" + report_Name, "GET", new MyHttpCallbackPdfUtil() {
            @Override
            public void onSuccess(BufferedInputStream data) {
                if (data != null) {
                    inputStream = data;
                    pdfView.fromStream(inputStream).load();
                }
            }

            @Override
            public void onFailure(String data) {
                FailureResponse<String> result = MyJsonUtil.fromJson(data, new TypeToken<FailureResponse<String>>() {
                }.getType());
                MyToastUtil.show(context, result.getMsg());
            }
        });

        //Back Button
        iv_back.setOnClickListener(v -> finish());
    }
}