/*
 * NTU Wenjia Geng (c) All rights reserved
 * None of this code can be reproduced or partly re-used without the permission
 * from Wenjia Geng (wenjia.geng2020@my.ntu.ac.uk).
 */
package com.ffsmartclient.ui.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Spinner;

import com.ffsmartclient.common.LoginSession;
import com.ffsmartclient.model.Order;
import com.ffsmartclient.R;
import com.ffsmartclient.utils.httputils.FailureResponse;
import com.ffsmartclient.utils.httputils.MyHttpCallbackUtil;
import com.ffsmartclient.utils.httputils.MyHttpUtil;
import com.ffsmartclient.utils.httputils.MyUrlConfig;
import com.ffsmartclient.utils.httputils.Response;
import com.ffsmartclient.utils.MyJsonUtil;
import com.ffsmartclient.utils.MyLogUtil;
import com.ffsmartclient.utils.MyToastUtil;
import com.ffsmartclient.ui.adapter.MyAdapter;
import com.ffsmartclient.ui.adapter.ViewHolder;
import com.google.gson.reflect.TypeToken;

import java.util.List;

/**
 * Orders Page Controller
 *
 * @author Wenjia Geng
 */

public class OrdersActivity extends AppCompatActivity {

    private ListView listView;

    private Activity context;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_orders);
        context = this;

        ImageView iv_back;
        Button btn_placeNewOrder;

        iv_back = findViewById(R.id.iv_back);
        listView = findViewById(R.id.listView);
        btn_placeNewOrder = findViewById(R.id.btn_placeNewOrder);

        if (LoginSession.getUser().getRole() != 2) {
            btn_placeNewOrder.setVisibility(View.GONE);
        }

        getAllOrders();

        //Spinner
        Spinner spinner = (Spinner) findViewById(R.id.spinner);
        // Create an ArrayAdapter using the string array and a default spinner layout
        ArrayAdapter<CharSequence> adapterSpinner = ArrayAdapter.createFromResource(this,
                R.array.order_spinner, android.R.layout.simple_spinner_item);
        // Specify the layout to use when the list of choices appears
        adapterSpinner.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        // Apply the adapter to the spinner
        spinner.setAdapter(adapterSpinner);
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                MyLogUtil.log("Selected Option: " + parent.getItemAtPosition(position));
                if (position == 0) {
                    getAllOrders();
                } else if (position == 1) {
                    getAllOrdersWithStatus(0);
                } else if (position == 2) {
                    getAllOrdersWithStatus(1);
                } else if (position == 3) {
                    getAllOrdersWithStatus(2);
                } else if (position == 4) {
                    getAllOrdersWithStatus(3);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                throw new UnsupportedOperationException();
            }
        });

        //Place new order Button
        btn_placeNewOrder.setOnClickListener(v -> {
            Intent intent = new Intent();
            intent.setClass(context, OrderPlaceActivity.class);
            startActivity(intent);
        });

        //Back Button
        iv_back.setOnClickListener(v -> finish());
    }

    /**
     * Update orders list
     */
    @Override
    protected void onResume() {
        super.onResume();
        getAllOrders();
    }

    /**
     * Update Order List
     */
    private void updateOrderList(Response<List<Order>> result) {
        List<Order> orders = result.getData();
        /**
         * Display the all orders in a ListView
         */
        MyAdapter<Order> adapter = new MyAdapter<Order>(context, orders, R.layout.item_orders) {
            @Override
            public void convert(ViewHolder helper, Order order, int position) {
                //0-ready
                //1-submitted
                //2-dispatched
                //3- delivered
                helper.setText(R.id.tv_orderId, order.getId());
                helper.setText(R.id.tv_deliveryDate, order.getDeliveryDate());
                helper.setText(R.id.tv_orderPlaceDate, order.getPlacedDate());
                String status;
                if (order.getStatus() == 0) {
                    status = "Waiting for approval";
                } else if (order.getStatus() == 1) {
                    status = "Approved";
                } else if (order.getStatus() == 2) {
                    status = "Dispatched";
                } else {
                    status = "Delivered";
                }
                helper.setText(R.id.tv_orderStatus, status);

                /**
                 * Check the order details
                 */
                helper.getView(R.id.iv_infoOrder).setOnClickListener(v -> {
                    Intent intent = new Intent();
                    intent.setClass(context, OrderDetailsActivity.class);
                    intent.putExtra("Order_id", order.getId());
                    startActivity(intent);
                });
            }
        };
        listView.setAdapter(adapter);
    }

    /**
     * Get All orders request
     */
    private void getAllOrders() {
        /**
         * Send a GET method "get all order placed" request to the server
         */
        MyHttpUtil.getWithToken(MyUrlConfig.order, "GET", new MyHttpCallbackUtil() {
            @Override
            public void onSuccess(String data) {
                Response<List<Order>> result = MyJsonUtil.fromJson(data, new TypeToken<Response<List<Order>>>() {
                }.getType());
                if (result != null) {
                    updateOrderList(result);
                }
            }

            @Override
            public void onFailure(String data) {
                FailureResponse<String> result = MyJsonUtil.fromJson(data, new TypeToken<FailureResponse<String>>() {
                }.getType());
                MyToastUtil.show(context, result.getMsg());
            }
        });
    }

    /**
     * Get All orders with status request
     */
    private void getAllOrdersWithStatus(int status) {
        /**
         * Send a GET method "get all order placed" request to the server
         */
        MyHttpUtil.getWithToken(MyUrlConfig.order + "?status=" + status, "GET", new MyHttpCallbackUtil() {
            @Override
            public void onSuccess(String data) {
                Response<List<Order>> result = MyJsonUtil.fromJson(data, new TypeToken<Response<List<Order>>>() {
                }.getType());
                if (result != null) {
                    updateOrderList(result);
                }
            }

            @Override
            public void onFailure(String data) {
                FailureResponse<String> result = MyJsonUtil.fromJson(data, new TypeToken<FailureResponse<String>>() {
                }.getType());
                MyToastUtil.show(context, result.getMsg());
            }
        });
    }
}