/*
 * NTU Wenjia Geng (c) All rights reserved
 * None of this code can be reproduced or partly re-used without the permission
 * from Wenjia Geng (wenjia.geng2020@my.ntu.ac.uk).
 */
package com.ffsmartclient.utils.httputils;

/**
 * Unifies the format of the Http response
 *
 * @author Wenjia Geng
 */
public class Response<T> {

    private String message;

    private T data;

    private String token;

    public Response( String message, T data, String token) {
        this.message = message;
        this.data = data;
        this.token = token;
    }

    public String getMsg() {
        return message;
    }

    public void setMsg(String message) {
        this.message = message;
    }

    public T getData() {
        return data;
    }

    public void setData(T data) {
        this.data = data;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }
}