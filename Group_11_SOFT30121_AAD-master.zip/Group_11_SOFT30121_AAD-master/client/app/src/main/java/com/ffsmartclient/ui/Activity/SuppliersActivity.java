/*
 * NTU Wenjia Geng (c) All rights reserved
 * None of this code can be reproduced or partly re-used without the permission
 * from Wenjia Geng (wenjia.geng2020@my.ntu.ac.uk).
 */
package com.ffsmartclient.ui.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.ListView;

import com.ffsmartclient.model.Supplier;
import com.ffsmartclient.R;
import com.ffsmartclient.utils.httputils.FailureResponse;
import com.ffsmartclient.utils.httputils.MyHttpCallbackUtil;
import com.ffsmartclient.utils.httputils.MyHttpUtil;
import com.ffsmartclient.utils.httputils.MyUrlConfig;
import com.ffsmartclient.utils.httputils.Response;
import com.ffsmartclient.utils.MyJsonUtil;
import com.ffsmartclient.utils.MyToastUtil;
import com.ffsmartclient.ui.adapter.MyAdapter;
import com.ffsmartclient.ui.adapter.ViewHolder;
import com.google.gson.reflect.TypeToken;

import java.util.List;

/**
 * Supplier Page Controller
 *
 * @author Wenjia Geng
 */

public class SuppliersActivity extends AppCompatActivity {

    private ListView listView;

    private Activity context;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_suppliers);
        context = this;

        ImageView iv_back;
        iv_back = findViewById(R.id.iv_back);
        listView = findViewById(R.id.listView);

        /**
         * Send a GET method "get all suppliers" request to the server
         */
        MyHttpUtil.getWithToken(MyUrlConfig.supplier + "?supplierName=", "GET", new MyHttpCallbackUtil() {
            @Override
            public void onSuccess(String data) {
                Response<List<Supplier>> result = MyJsonUtil.fromJson(data, new TypeToken<Response<List<Supplier>>>() {
                }.getType());
                if (result != null) {
                    List<Supplier> suppliers = result.getData();
                    /**
                     * Display the items that the supplier provided in a ListView
                     */
                    MyAdapter<Supplier> adapter = new MyAdapter<Supplier>(context, suppliers, R.layout.item_suppliers) {
                        @Override
                        public void convert(ViewHolder helper, Supplier supplier, int position) {
                            helper.setText(R.id.tv_supplierName, supplier.getName());
                            /**
                             * Check the supplier details
                             */
                            helper.getView(R.id.iv_infoSupplier).setOnClickListener(v -> {
                                Intent intent = new Intent();
                                intent.setClass(context, SupplierDetailsActivity.class);
                                intent.putExtra("Supplier_id", supplier.getId());
                                startActivity(intent);
                            });
                        }
                    };
                    listView.setAdapter(adapter);
                }
            }

            @Override
            public void onFailure(String data) {
                FailureResponse<String> result = MyJsonUtil.fromJson(data, new TypeToken<FailureResponse<String>>() {
                }.getType());
                MyToastUtil.show(context, result.getMsg());
            }
        });

        //Back Button
        iv_back.setOnClickListener(v -> finish());
    }
}