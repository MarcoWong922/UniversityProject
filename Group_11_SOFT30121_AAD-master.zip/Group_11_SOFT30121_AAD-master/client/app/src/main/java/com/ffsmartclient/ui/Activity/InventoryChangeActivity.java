/*
 * NTU Wenjia Geng (c) All rights reserved
 * None of this code can be reproduced or partly re-used without the permission
 * from Wenjia Geng (wenjia.geng2020@my.ntu.ac.uk).
 */
package com.ffsmartclient.ui.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.ListView;

import com.ffsmartclient.model.InventoryChange;
import com.ffsmartclient.R;
import com.ffsmartclient.utils.httputils.FailureResponse;
import com.ffsmartclient.utils.httputils.MyHttpCallbackUtil;
import com.ffsmartclient.utils.httputils.MyHttpUtil;
import com.ffsmartclient.utils.httputils.MyUrlConfig;
import com.ffsmartclient.utils.httputils.Response;
import com.ffsmartclient.utils.MyJsonUtil;
import com.ffsmartclient.utils.MyToastUtil;
import com.ffsmartclient.ui.adapter.MyAdapter;
import com.ffsmartclient.ui.adapter.ViewHolder;
import com.google.gson.reflect.TypeToken;

import java.util.List;

/**
 * Inventory Item Change History Page Controller
 *
 * @author Wenjia Geng
 */

public class InventoryChangeActivity extends AppCompatActivity {

    private ListView listView;
    private List<InventoryChange> inventoryChanges;

    private Activity context;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory_change);
        context = this;

        ImageView iv_back;
        iv_back = findViewById(R.id.iv_back);
        listView = findViewById(R.id.listView);

        /**
         * Send a GET method "get all inventory changes" request to the server
         */
        MyHttpUtil.getWithToken(MyUrlConfig.inventory+"/change-history", "GET", new MyHttpCallbackUtil() {
            @Override
            public void onSuccess(String data) {
                Response<List<InventoryChange>> result = MyJsonUtil.fromJson(data, new TypeToken<Response<List<InventoryChange>>>(){}.getType());
                if(result != null){
                    inventoryChanges = result.getData();
                    /**
                     * Display the inventory changes in a ListView
                     */
                    MyAdapter<InventoryChange> adapter = new MyAdapter<InventoryChange>(context, inventoryChanges, R.layout.item_inventory_changes) {
                        @Override
                        public void convert(ViewHolder helper, InventoryChange inventoryChange, int position) {
                            String operation;
                            int remove = 0;
                            if(inventoryChange.getOperation() == remove){
                                operation = "Remove";
                            }else{
                                operation = "Insert";
                            }
                            helper.setText(R.id.tv_operation, operation);
                            helper.setText(R.id.tv_operationDate, inventoryChange.getDate());
                            helper.setText(R.id.tv_userId, inventoryChange.getUserId());

                            /**
                             * Check the supplier details
                             */
                            helper.getView(R.id.iv_infoInventoryChange).setOnClickListener(v -> {
                                Intent intent = new Intent();
                                intent.setClass(context, InventoryChangeDetailsActivity.class);
                                intent.putExtra("Change_id", inventoryChange.getId());
                                startActivity(intent);
                            });
                        }
                    };
                    listView.setAdapter(adapter);
                }
            }

            @Override
            public void onFailure(String data){
                FailureResponse<String> result = MyJsonUtil.fromJson(data, new TypeToken<FailureResponse<String>>(){}.getType());
                MyToastUtil.show(context, result.getMsg());
            }
        });

        //Back Button
        iv_back.setOnClickListener(v -> finish());
    }
}