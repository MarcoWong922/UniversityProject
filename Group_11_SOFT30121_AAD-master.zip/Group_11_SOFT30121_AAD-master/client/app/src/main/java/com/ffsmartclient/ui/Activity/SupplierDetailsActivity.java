/*
 * NTU Wenjia Geng (c) All rights reserved
 * None of this code can be reproduced or partly re-used without the permission
 * from Wenjia Geng (wenjia.geng2020@my.ntu.ac.uk).
 */
package com.ffsmartclient.ui.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.ffsmartclient.model.Item;
import com.ffsmartclient.model.Supplier;
import com.ffsmartclient.R;
import com.ffsmartclient.utils.httputils.FailureResponse;
import com.ffsmartclient.utils.httputils.MyHttpCallbackUtil;
import com.ffsmartclient.utils.httputils.MyHttpUtil;
import com.ffsmartclient.utils.httputils.MyUrlConfig;
import com.ffsmartclient.utils.httputils.Response;
import com.ffsmartclient.utils.MyJsonUtil;
import com.ffsmartclient.utils.MyToastUtil;
import com.ffsmartclient.ui.adapter.MyAdapter;
import com.ffsmartclient.ui.adapter.ViewHolder;
import com.google.gson.reflect.TypeToken;

import java.util.ArrayList;
import java.util.List;

/**
 * Supplier Details Page Controller
 *
 * @author Wenjia Geng
 */

public class SupplierDetailsActivity extends AppCompatActivity {

    private TextView tv_supplierId;
    private TextView tv_supplierName;
    private TextView tv_supplierEmail;
    private TextView tv_supplierPhone;
    private ListView listView;

    private List<Item> items = new ArrayList<>();

    private Supplier supplier;

    private Activity context;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_supplier_details);
        context = this;

        ImageView iv_back;
        String supplier_id;

        iv_back = findViewById(R.id.iv_back);
        tv_supplierId = findViewById(R.id.tv_supplierId);
        tv_supplierName = findViewById(R.id.tv_supplierName);
        tv_supplierEmail = findViewById(R.id.tv_supplierEmail);
        tv_supplierPhone = findViewById(R.id.tv_supplierPhone);

        listView = findViewById(R.id.listView);

        //Get the supplier id of the supplier object selected in the previous page
        supplier_id = getIntent().getStringExtra("Supplier_id");

        /**
         * Send a GET method "get supplier by supplier Id" request to the server
         */
        MyHttpUtil.getWithToken(MyUrlConfig.supplier + "/" + supplier_id, "GET", new MyHttpCallbackUtil() {
            @Override
            public void onSuccess(String data) {
                Response<Supplier> result = MyJsonUtil.fromJson(data, new TypeToken<Response<Supplier>>() {
                }.getType());
                if (result != null) {
                    supplier = result.getData();
                    tv_supplierId.setText("Supplier ID: " + supplier.getId());
                    tv_supplierName.setText(supplier.getName());
                    tv_supplierEmail.setText(supplier.getEmail());
                    tv_supplierPhone.setText(supplier.getPhone());
                    items = supplier.getItems();
                    /**
                     * Display the items that the supplier provided in a ListView
                     */
                    MyAdapter<Item> adapter = new MyAdapter<Item>(context, items, R.layout.item_items) {
                        @Override
                        public void convert(ViewHolder helper, Item item, int position) {
                            helper.setText(R.id.tv_itemName, item.getName());
                        }
                    };
                    listView.setAdapter(adapter);
                }
            }

            @Override
            public void onFailure(String data) {
                FailureResponse<String> result = MyJsonUtil.fromJson(data, new TypeToken<FailureResponse<String>>() {
                }.getType());
                MyToastUtil.show(context, result.getMsg());
            }
        });

        iv_back.setOnClickListener(v -> finish());
    }
}