/*
 * NTU Wenjia Geng (c) All rights reserved
 * None of this code can be reproduced or partly re-used without the permission
 * from Wenjia Geng (wenjia.geng2020@my.ntu.ac.uk).
 */
package com.ffsmartclient.utils.httputils;

import java.io.BufferedInputStream;

/**
 * Interface for PDF Reader
 *
 * @author Wenjia Geng
 */

public interface MyHttpCallbackPdfUtil {

    void onSuccess(BufferedInputStream is);

    void onFailure(String data);

}
