/*
 * NTU Wenjia Geng (c) All rights reserved
 * None of this code can be reproduced or partly re-used without the permission
 * from Wenjia Geng (wenjia.geng2020@my.ntu.ac.uk).
 */
package com.ffsmartclient.ui.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Base64;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.resource.bitmap.CircleCrop;
import com.ffsmartclient.common.LoginSession;
import com.ffsmartclient.model.User;
import com.ffsmartclient.R;
import com.ffsmartclient.utils.MyLogUtil;

/**
 * Home Page Controller
 *
 * @author Wenjia Geng
 */

public class MainActivity extends AppCompatActivity {

    private TextView tv_hi;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Activity context = this;

        LinearLayout layout_headChefButtons;
        LinearLayout layout_driverButtons;
        LinearLayout layout_chefButtons;
        LinearLayout layout_shared;
        ImageView iv_avatar;
        Button btn_alert;
        Button btn_userManagement;
        Button btn_allOrders;
        Button btn_myOrders;
        Button btn_insert;
        Button btn_remove;
        Button btn_inventory;
        Button btn_history;
        Button btn_order;
        Button btn_supplier;
        Button btn_profile;
        Button btn_logout;
        Button btn_reports;

        tv_hi = findViewById(R.id.tv_hi);
        iv_avatar = findViewById(R.id.iv_avatar);

        layout_headChefButtons = findViewById(R.id.layout_headChefButtons);
        btn_alert = findViewById(R.id.btn_alert);
        btn_alert.setBackgroundColor(Color.parseColor("#ee4035"));
        btn_userManagement = findViewById(R.id.btn_userManagement);
        btn_userManagement.setBackgroundColor(Color.parseColor("#7bc043"));
        btn_reports = findViewById(R.id.btn_reports);
        btn_reports.setBackgroundColor(Color.parseColor("#f37736"));
        btn_order = findViewById(R.id.btn_order);
        btn_order.setBackgroundColor(Color.parseColor("#0392cf"));

        layout_driverButtons = findViewById(R.id.layout_driverButtons);
        btn_allOrders = findViewById(R.id.btn_allOrders);
        btn_allOrders.setBackgroundColor(Color.parseColor("#0000a0"));
        btn_myOrders = findViewById(R.id.btn_myOrders);
        btn_myOrders.setBackgroundColor(Color.parseColor("#a00000"));

        layout_chefButtons = findViewById(R.id.layout_chefButtons);
        btn_insert = findViewById(R.id.btn_insert);
        btn_insert.setBackgroundColor(Color.parseColor("#0000a0"));
        btn_remove = findViewById(R.id.btn_remove);
        btn_remove.setBackgroundColor(Color.parseColor("#a00000"));
        btn_inventory = findViewById(R.id.btn_inventory);
        btn_inventory.setBackgroundColor(Color.parseColor("#3232b3"));
        btn_history = findViewById(R.id.btn_history);
        btn_history.setBackgroundColor(Color.parseColor("#9999d9"));
        btn_supplier = findViewById(R.id.btn_supplier);
        btn_supplier.setBackgroundColor(Color.parseColor("#b33232"));
        layout_shared = findViewById(R.id.layout_shared);
        btn_profile = findViewById(R.id.btn_profile);
        btn_profile.setBackgroundColor(Color.parseColor("#6666c6"));
        btn_logout = findViewById(R.id.btn_logout);
        btn_logout.setBackgroundColor(Color.parseColor("#c66666"));

        User user = LoginSession.getUser();
        tv_hi.setText("Hi, "+user.getFirstName()+" "+user.getLastName()+"!");
        if (user.getAvatar() == null) {
            Glide.with(this)
                    .load(R.drawable.avatar)
                    .transform(new CircleCrop())
                    .into((ImageView) findViewById(R.id.iv_avatar));
        }

        //Initial components  0-driver 1-chef 2-head chef
         int userRole = user.getRole();
         switch(userRole){

             //Driver
             case 0:
                 layout_headChefButtons.setVisibility(View.GONE);
                 layout_driverButtons.setVisibility(View.VISIBLE);
                 layout_chefButtons.setVisibility(View.GONE);
                 layout_shared.setVisibility(View.VISIBLE);
                 btn_history.setVisibility(View.GONE);
                 break;
             //Chef
             case 1:
                 layout_headChefButtons.setVisibility(View.GONE);
                 layout_driverButtons.setVisibility(View.GONE);
                 layout_chefButtons.setVisibility(View.VISIBLE);
                 layout_shared.setVisibility(View.VISIBLE);
                 break;
             //Head Chef
             case 2:
                 layout_headChefButtons.setVisibility(View.VISIBLE);
                 layout_driverButtons.setVisibility(View.GONE);
                 layout_chefButtons.setVisibility(View.VISIBLE);
                 layout_shared.setVisibility(View.VISIBLE);
                 break;
             default:
                 break;
         }

         //Logout Button
        btn_logout.setOnClickListener(v -> {
            LoginSession.logout();
            Intent intent = new Intent();
            intent.setClass(context, LoginActivity.class);
            startActivity(intent);
            context.finish();
        });

         //Insert Button
        btn_insert.setOnClickListener(v -> {
            Intent intent = new Intent();
            intent.setClass(context, InsertActivity.class);
            startActivity(intent);
        });

        //Remove Button
        btn_remove.setOnClickListener(v -> {
            Intent intent = new Intent();
            intent.setClass(context, RemoveActivity.class);
            startActivity(intent);
        });

        //Inventory Button
        btn_inventory.setOnClickListener(v -> {
            Intent intent = new Intent();
            intent.setClass(context, InventoryActivity.class);
            startActivity(intent);
        });

        //Suppliers Button
        btn_supplier.setOnClickListener(v -> {
            Intent intent = new Intent();
            intent.setClass(context, SuppliersActivity.class);
            startActivity(intent);
        });

        //Inventory Changes Button
        btn_history.setOnClickListener(v -> {
            Intent intent = new Intent();
            intent.setClass(context, InventoryChangeActivity.class);
            startActivity(intent);
        });

        //All Orders Button
        btn_order.setOnClickListener(v -> {
            Intent intent = new Intent();
            intent.setClass(context, OrdersActivity.class);
            startActivity(intent);
        });

        //My Profile Button
        btn_profile.setOnClickListener(v -> {
            Intent intent = new Intent();
            intent.setClass(context, MyProfileActivity.class);
            startActivity(intent);
        });

        //Alert Button
        btn_alert.setOnClickListener(v -> {
            Intent intent = new Intent();
            intent.setClass(context, AlertActivity.class);
            startActivity(intent);
        });

        //User Management Button
        btn_userManagement.setOnClickListener(v -> {
            Intent intent = new Intent();
            intent.setClass(context, UserAccountActivity.class);
            startActivity(intent);
        });


        //Driver Orders Button
        btn_allOrders.setOnClickListener(v -> {
            Intent intent = new Intent();
            intent.setClass(context, DriverOrdersActivity.class);
            startActivity(intent);
        });

        //Driver My Orders Button
        btn_myOrders.setOnClickListener(v -> {
            Intent intent = new Intent();
            intent.setClass(context, DriverMyOrdersActivity.class);
            startActivity(intent);
        });

        //Health Report Button
        btn_reports.setOnClickListener(v -> {
            Intent intent = new Intent();
            intent.setClass(context, ReportsActivity.class);
            startActivity(intent);
        });

        //Avatar click
        iv_avatar.setOnClickListener(v -> {
            Intent intent = new Intent();
            intent.setClass(context, MyProfileActivity.class);
            startActivity(intent);
        });
    }


    /**
     * Update user avatar & Slogan
     */
    @Override
    protected void onResume() {
        super.onResume();
        User user = LoginSession.getUser();
        String slogan = "Hi, "+user.getFirstName()+" "+user.getLastName()+"!";
        tv_hi.setText(slogan);
        if( user.getAvatar() != null){
            byte[] bytes = Base64.decode(user.getAvatar(), Base64.DEFAULT);
            Bitmap bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
            Glide.with(this)
                    .load(bitmap)
                    .error(R.drawable.avatar)
                    .transform(new CircleCrop())
                    .into((ImageView) findViewById(R.id.iv_avatar));
        }
    }
}