/*
 * NTU Wenjia Geng (c) All rights reserved
 * None of this code can be reproduced or partly re-used without the permission
 * from Wenjia Geng (wenjia.geng2020@my.ntu.ac.uk).
 */
package com.ffsmartclient.ui.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.blankj.utilcode.util.SPUtils;
import com.ffsmartclient.common.LoginSession;
import com.ffsmartclient.model.Inventory;
import com.ffsmartclient.R;
import com.ffsmartclient.utils.httputils.FailureResponse;
import com.ffsmartclient.utils.httputils.MyHttpCallbackUtil;
import com.ffsmartclient.utils.httputils.MyHttpUtil;
import com.ffsmartclient.utils.httputils.MyUrlConfig;
import com.ffsmartclient.utils.httputils.Response;
import com.ffsmartclient.utils.MyJsonUtil;
import com.ffsmartclient.utils.MyLogUtil;
import com.ffsmartclient.utils.MyToastUtil;
import com.ffsmartclient.ui.adapter.MyAdapter;
import com.ffsmartclient.ui.adapter.ViewHolder;
import com.ffsmartclient.ui.dialog.InventoryItemSelectDialog;
import com.google.gson.reflect.TypeToken;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

/**
 * Remove Inventory Item Page Controller
 *
 * @author Wenjia Geng
 */

public class RemoveActivity extends AppCompatActivity {

    private TextView tv_itemSelect;
    private EditText edit_quantity;

    private Inventory selectInventoryItem;

    private List<Inventory> items = new ArrayList<>();

    private Activity context;

    private MyAdapter<Inventory> myAdapter;

    private static final String REMOVE_INVENTORY = "RemoveInventory";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_remove);
        context = this;

        ImageView iv_back;
        Button btn_add;
        Button btn_removeConfirm;
        ListView listView;
        tv_itemSelect = findViewById(R.id.tv_itemSelect);
        tv_itemSelect.getPaint().setFlags(Paint.UNDERLINE_TEXT_FLAG);
        iv_back = findViewById(R.id.iv_back);
        edit_quantity = findViewById(R.id.edit_quantity);
        btn_add = findViewById(R.id.btn_add);
        btn_add.setBackgroundColor(Color.parseColor("#a00000"));
        listView = findViewById(R.id.listView);

        btn_removeConfirm = findViewById(R.id.btn_removeConfirm);

        //Reload Previous Added Remove Items
        String listInventoryItemsJson = SPUtils.getInstance().getString(LoginSession.getUid() + REMOVE_INVENTORY);
        if (!"".equals(listInventoryItemsJson)) {
            items = MyJsonUtil.fromJson(listInventoryItemsJson, new TypeToken<List<Inventory>>() {
            }.getType());
        }


        /**
         * Display the added Remove Inventory Items in the ListView
         */
        myAdapter = new MyAdapter<Inventory>(context, items, R.layout.item_removed_inventory) {
            @Override
            public void convert(ViewHolder helper, Inventory inventory, int position) {
                helper.setText(R.id.tv_inventoryItemName, inventory.getItemName());
                helper.setText(R.id.tv_expiryDate, inventory.getExpiryDate());
                helper.setText(R.id.tv_insertQuantity, " " + inventory.getQuantity());

                /**
                 * Delete added item
                 */
                helper.getView(R.id.iv_deleteInventoryItem).setOnClickListener(v -> {
                    items.remove(position);
                    myAdapter.notifyDataSetChanged();
                });

            }
        };
        listView.setAdapter(myAdapter);

        /**
         * Pop-up window to Add Available Item
         */
        tv_itemSelect.setOnClickListener(v ->
                new InventoryItemSelectDialog(context, new InventoryItemSelectDialog.Callback() {
                    @Override
                    public void onCall(Inventory inventory) { //get the item name
                        MyLogUtil.log("Selected inventory item Object: " + inventory);
                        selectInventoryItem = inventory;
                        if (selectInventoryItem != null) {
                            tv_itemSelect.setText(selectInventoryItem.getItemName() + " -Expiry date: " + selectInventoryItem.getExpiryDate());
                        }
                    }
                })
        );

        //Add New Item
        btn_add.setOnClickListener((v -> {
            String quantityStr = edit_quantity.getText().toString();

            //Check if the quantity is empty
            int quantity;
            boolean quantityCheckPass = Pattern.matches("^\\d+$", quantityStr);
            if ("".equals(quantityStr.trim())) {
                MyToastUtil.show(context, "Please enter the quantity");
                return;
            }
            //Check the age contains only digits
            else if (!quantityCheckPass) {
                MyToastUtil.show(context, "Quantity can only include digits");
                return;
            }
            //Convert string type ageStr to int type age
            else {
                quantity = Integer.parseInt(quantityStr);
                if (selectInventoryItem.getQuantity() < quantity) {
                    MyToastUtil.show(context, "Entered quantity exceeding stock quantity");
                    return;
                }
            }

            selectInventoryItem.setQuantity(quantity);

            items.add(selectInventoryItem);
            resetAddItem();

            myAdapter.notifyDataSetChanged();//Notify the adapter to display new data

        }));


        //Back Button
        iv_back.setOnClickListener(v -> {
            SPUtils.getInstance().put(LoginSession.getUid() + REMOVE_INVENTORY, MyJsonUtil.toJson(items));
            finish();
        });

        //Submit Insert InventoryItems List
        btn_removeConfirm.setOnClickListener(v ->
                /**
                 * Send a POST method "Insert new Inventory" request to the server
                 */
                MyHttpUtil.postWithToken(MyUrlConfig.inventory + "/remove", items, "POST", new MyHttpCallbackUtil() {
                    @Override
                    public void onSuccess(String data) {
                        //When the request successfully returns Json String data, convert the json data to the user type object
                        Response<Inventory> result = MyJsonUtil.fromJson(data, new TypeToken<Response<Inventory>>() {
                        }.getType());
                        MyToastUtil.show(context, result.getMsg());
                        //Reset InsertInventory List
                        SPUtils.getInstance().put(LoginSession.getUid() + REMOVE_INVENTORY, "");
                        items.clear();
                        myAdapter.notifyDataSetChanged();
                    }

                    @Override
                    public void onFailure(String data) {
                        FailureResponse<String> result = MyJsonUtil.fromJson(data, new TypeToken<FailureResponse<String>>() {
                        }.getType());
                        MyToastUtil.show(context, result.getMsg());

                    }
                })
        );
    }

    private void resetAddItem() {
        tv_itemSelect.setText("");
        edit_quantity.setText("");
    }

}