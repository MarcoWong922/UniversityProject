/*
 * NTU Wenjia Geng (c) All rights reserved
 * None of this code can be reproduced or partly re-used without the permission
 * from Wenjia Geng (wenjia.geng2020@my.ntu.ac.uk).
 */
package com.ffsmartclient.ui.dialog;

import android.app.Dialog;
import android.content.Context;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import androidx.annotation.NonNull;

import com.ffsmartclient.model.Item;
import com.ffsmartclient.R;
import com.ffsmartclient.utils.httputils.FailureResponse;
import com.ffsmartclient.utils.httputils.MyHttpCallbackUtil;
import com.ffsmartclient.utils.httputils.MyHttpUtil;
import com.ffsmartclient.utils.httputils.MyUrlConfig;
import com.ffsmartclient.utils.httputils.Response;
import com.ffsmartclient.utils.MyJsonUtil;
import com.ffsmartclient.utils.MyToastUtil;
import com.ffsmartclient.ui.adapter.MyAdapter;
import com.ffsmartclient.ui.adapter.ViewHolder;
import com.google.gson.reflect.TypeToken;

import java.util.List;

/**
 * Items Select Dialog
 *
 * @author Wenjia Geng
 */

public class ItemSelectDialog extends Dialog {

    private EditText edit_search;
    private Button btn_search;
    private ListView listView;
    private List<Item> itemList;

    public ItemSelectDialog(@NonNull Context context, Callback callback) {
        super(context);
        setContentView(R.layout.dialog_item);
        //Display dialog
        show();
        edit_search = findViewById(R.id.edit_search);
        btn_search = findViewById(R.id.btn_search);
        listView = findViewById(R.id.listView);


        listView.setOnItemClickListener((adapterView, view, i, l) -> {
            if (itemList != null && itemList.size() > i) {
                Item item = itemList.get(i);
                callback.onCall(item);
                dismiss();
            }
        });

        //Get All Available Items
        MyHttpUtil.getWithToken(MyUrlConfig.item, "GET", new MyHttpCallbackUtil() {
            @Override
            public void onSuccess(String data) {
                Response<List<Item>> result = MyJsonUtil.fromJson(data, new TypeToken<Response<List<Item>>>() {
                }.getType());
                if (result != null) {
                    itemList = result.getData();
                    MyAdapter<Item> adapter = new MyAdapter<Item>(context, itemList, R.layout.item_items) {
                        @Override
                        public void convert(ViewHolder helper, Item item, int position) {
                            helper.setText(R.id.tv_itemName, item.getName());
                        }
                    };
                    listView.setAdapter(adapter);
                }
            }

            @Override
            public void onFailure(String data) {
                FailureResponse<String> result = MyJsonUtil.fromJson(data, new TypeToken<FailureResponse<String>>() {
                }.getType());
                MyToastUtil.show(context, result.getMsg());

            }
        });

        /**
         * Search for items available
         */
        btn_search.setOnClickListener(v -> {
            String itemName = edit_search.getText().toString();

            //get all item available
            MyHttpUtil.getWithToken(MyUrlConfig.item + "?name=" + itemName, "GET", new MyHttpCallbackUtil() {
                @Override
                public void onSuccess(String data) {
                    Response<List<Item>> result = MyJsonUtil.fromJson(data, new TypeToken<Response<List<Item>>>() {
                    }.getType());
                    if (result != null) {
                        itemList = result.getData();
                        MyAdapter<Item> adapter = new MyAdapter<Item>(context, itemList, R.layout.item_items) {
                            @Override
                            public void convert(ViewHolder helper, Item item, int position) {
                                helper.setText(R.id.tv_itemName, item.getName());
                            }
                        };
                        listView.setAdapter(adapter);
                    }
                }

                @Override
                public void onFailure(String data) {
                    FailureResponse<String> result = MyJsonUtil.fromJson(data, new TypeToken<FailureResponse<String>>() {
                    }.getType());
                    MyToastUtil.show(context, result.getMsg());
                }
            });
        });
    }

    /**
     * CityDat callback interface (need override)
     */
    public interface Callback {
        void onCall(Item item);
    }
}