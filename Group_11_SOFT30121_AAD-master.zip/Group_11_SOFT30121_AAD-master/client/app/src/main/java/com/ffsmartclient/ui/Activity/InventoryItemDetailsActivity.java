/*
 * NTU Wenjia Geng (c) All rights reserved
 * None of this code can be reproduced or partly re-used without the permission
 * from Wenjia Geng (wenjia.geng2020@my.ntu.ac.uk).
 */
package com.ffsmartclient.ui.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.SpannableString;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.ffsmartclient.model.Inventory;
import com.ffsmartclient.R;
import com.ffsmartclient.utils.httputils.FailureResponse;
import com.ffsmartclient.utils.httputils.MyHttpCallbackUtil;
import com.ffsmartclient.utils.httputils.MyHttpUtil;
import com.ffsmartclient.utils.httputils.MyUrlConfig;
import com.ffsmartclient.utils.httputils.Response;
import com.ffsmartclient.utils.MyJsonUtil;
import com.ffsmartclient.utils.MyToastUtil;
import com.google.gson.reflect.TypeToken;

/**
 * Inventory Item Details Page Controller
 *
 * @author Wenjia Geng
 */

public class InventoryItemDetailsActivity extends AppCompatActivity {

    private TextView tv_inventoryItemId;
    private TextView tv_itemName;
    private TextView tv_expiryDate;
    private TextView tv_supplierName;
    private EditText edit_itemQuantity;
    private Button btn_quantityConfirm;


    private Activity context;
    private Inventory inventoryItem;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory_item_details);

        context = this;

        ImageView iv_back;
        ImageView iv_info;
        iv_back = findViewById(R.id.iv_back);
        tv_inventoryItemId = findViewById(R.id.tv_inventoryItemId);
        tv_itemName = findViewById(R.id.tv_itemName);
        edit_itemQuantity = findViewById(R.id.edit_itemQuantity);
        tv_expiryDate = findViewById(R.id.tv_expiryDate);
        tv_supplierName = findViewById(R.id.tv_supplierName);
        iv_info = findViewById(R.id.iv_info);
        btn_quantityConfirm = findViewById(R.id.btn_quantityConfirm);

        //Get the inventory id of the inventory object selected in the previous page
        String inventoryId = getIntent().getStringExtra("Inventory_id");

        /**
         * Send a GET method "get inventory items by inventory Id" request to the server
         */
        MyHttpUtil.getWithToken(MyUrlConfig.inventory + "/" + inventoryId, "GET", new MyHttpCallbackUtil() {
            @Override
            public void onSuccess(String data) {
                Response<Inventory> result = MyJsonUtil.fromJson(data, new TypeToken<Response<Inventory>>() {
                }.getType());
                if (result != null) {
                    inventoryItem = result.getData();
                    String inventoryItemId = "Inventory Item ID: " + inventoryItem.getId();
                    tv_inventoryItemId.setText(inventoryItemId);
                    tv_itemName.setText(inventoryItem.getItemName());
                    tv_expiryDate.setText(inventoryItem.getExpiryDate());
                    SpannableString itemQuantity = new SpannableString(inventoryItem.getQuantity() + "");
                    edit_itemQuantity.setHint(itemQuantity);
                    tv_supplierName.setText(inventoryItem.getSupplierName());

                    //Update Inventory Item Quantity
                    btn_quantityConfirm.setOnClickListener(v -> {
                        //update quantity
                        String enterQuantity = edit_itemQuantity.getText().toString();
                        if (!"".equals(enterQuantity.trim())) {
                            int quantity = Integer.parseInt(edit_itemQuantity.getText().toString());
                            inventoryItem.setQuantity(quantity);
                        }

                        /**
                         * Send a PUT method "update inventory item quantity by inventory Id" request to the server
                         */
                        MyHttpUtil.postWithToken(MyUrlConfig.inventory + "/" + inventoryItem.getId(), inventoryItem, "PUT", new MyHttpCallbackUtil() {
                            @Override
                            public void onSuccess(String data) {
                                Response<Inventory> result = MyJsonUtil.fromJson(data, new TypeToken<Response<Inventory>>() {
                                }.getType());
                                if (result != null) {
                                    MyToastUtil.show(context, result.getMsg());
                                    inventoryItem = result.getData();
                                    SpannableString itemQuantity = new SpannableString(inventoryItem.getQuantity() + "");
                                    edit_itemQuantity.setHint(itemQuantity);
                                }
                            }

                            @Override
                            public void onFailure(String data) {
                                FailureResponse<String> result = MyJsonUtil.fromJson(data, new TypeToken<FailureResponse<String>>() {
                                }.getType());
                                MyToastUtil.show(context, result.getMsg());
                            }
                        });
                    });
                }
            }

            @Override
            public void onFailure(String data) {
                FailureResponse<String> result = MyJsonUtil.fromJson(data, new TypeToken<FailureResponse<String>>() {
                }.getType());
                MyToastUtil.show(context, result.getMsg());
            }
        });
        //Supplier Button
        iv_info.setOnClickListener(v -> {
            Intent intent = new Intent();
            intent.setClass(context, SupplierDetailsActivity.class);
            intent.putExtra("Supplier_id", inventoryItem.getSupplierId());//store the trip id within the "Supplier_id" key
            startActivity(intent);
        });
        //Back Button
        iv_back.setOnClickListener(v -> finish());
    }
}