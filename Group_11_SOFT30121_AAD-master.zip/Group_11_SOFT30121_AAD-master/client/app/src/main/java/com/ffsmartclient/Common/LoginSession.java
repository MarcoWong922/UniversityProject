/*
 * NTU Wenjia Geng (c) All rights reserved
 * None of this code can be reproduced or partly re-used without the permission
 * from Wenjia Geng (wenjia.geng2020@my.ntu.ac.uk).
 */
package com.ffsmartclient.common;

import com.blankj.utilcode.util.SPUtils;
import com.ffsmartclient.model.LoginToken;
import com.ffsmartclient.model.User;
import com.ffsmartclient.utils.httputils.Response;
import com.ffsmartclient.utils.MyJsonUtil;
import com.ffsmartclient.utils.MyLogUtil;
import com.google.gson.reflect.TypeToken;

/**
 * Get/Set Login User and User ID, Logout User
 *
 * @author Wenjia Geng
 */

public class LoginSession {

    private static final String USER_JSON = "user_json";

    public static User getUser(){
        String user_json = SPUtils.getInstance().getString(USER_JSON);
        Response<LoginToken> respJson = MyJsonUtil.fromJson(user_json, new TypeToken<Response<LoginToken>>(){}.getType());
        MyLogUtil.log("LoginUser JSON: " + user_json);
        if(respJson==null){
            return null;
        }
        LoginToken resultToken = respJson.getData();
        return resultToken.getUser();
    }

    public static void setUser(User user){
        String user_json = SPUtils.getInstance().getString(USER_JSON);
        Response<LoginToken> respJson = MyJsonUtil.fromJson(user_json, new TypeToken<Response<LoginToken>>(){}.getType());
        if(user != null){
            respJson.getData().setUser(user);
            SPUtils.getInstance().put(USER_JSON, MyJsonUtil.toJson(respJson));
        }
    }

    public static String getUid(){
        User user = getUser();
        if(user != null){
            return user.getId();
        }else {
            MyLogUtil.log("Failed to get Usr Id");
            return null;
        }
    }

    public static void logout(){
        User user = getUser();
        if(user != null){
            SPUtils.getInstance().put(USER_JSON, "");
            SPUtils.getInstance().put(user.getId(), "");
        }else {
            MyLogUtil.log("Failed to log user out");
        }
    }

}
