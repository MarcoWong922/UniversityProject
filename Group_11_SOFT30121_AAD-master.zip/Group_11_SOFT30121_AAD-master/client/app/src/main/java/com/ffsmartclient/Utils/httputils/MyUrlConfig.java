/*
 * NTU Wenjia Geng (c) All rights reserved
 * None of this code can be reproduced or partly re-used without the permission
 * from Wenjia Geng (wenjia.geng2020@my.ntu.ac.uk).
 */
package com.ffsmartclient.utils.httputils;

/**
 * Configure the url to access the server-side api for resources
 *
 * @author Wenjia Geng
 */

public class MyUrlConfig {

    private MyUrlConfig() {
        throw new IllegalStateException("MyUrlConfig class");
    }

    //base
    //private static final String base = "http://10.0.2.2:8080";//Local Emulator
    private static final String BASE = "http://172.16.6.11:8080";//Local laptop
    //private static final String BASE = "https://ffsmart-ffsmart.azuremicroservices.io";//Local laptop

    //user recourse api
    public static final String user = BASE + "/users";

    //ID recourse apis
    public static final String id = BASE + "/id";

    //Item recourse apis
    public static final String item = BASE + "/items";

    //Inventory recourse apis
    public static final String inventory = BASE + "/inventory";

    //Supplier recourse apis
    public static final String supplier = BASE + "/suppliers";

    //Order recourse apis
    public static final String order = BASE + "/orders";

    //Alert recourse apis
    public static final String alert = BASE + "/alerts";

    //Report recourse apis
    public static final String report = BASE + "/reports";

}