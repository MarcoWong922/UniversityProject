/*
 * NTU Wenjia Geng (c) All rights reserved
 * None of this code can be reproduced or partly re-used without the permission
 * from Wenjia Geng (wenjia.geng2020@my.ntu.ac.uk).
 */
package com.ffsmartclient.ui.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.ffsmartclient.model.Inventory;
import com.ffsmartclient.model.Order;
import com.ffsmartclient.R;
import com.ffsmartclient.utils.httputils.FailureResponse;
import com.ffsmartclient.utils.httputils.MyHttpCallbackUtil;
import com.ffsmartclient.utils.httputils.MyHttpUtil;
import com.ffsmartclient.utils.httputils.MyUrlConfig;
import com.ffsmartclient.utils.httputils.Response;
import com.ffsmartclient.utils.MyJsonUtil;
import com.ffsmartclient.utils.MyToastUtil;
import com.ffsmartclient.ui.adapter.MyAdapter;
import com.ffsmartclient.ui.adapter.ViewHolder;
import com.google.gson.reflect.TypeToken;

import java.util.List;

/**
 * Driver Order Details Page Controller
 *
 * @author Wenjia Geng
 */

public class DriverOrderDetailsActivity extends AppCompatActivity {

    private TextView tv_supplierName;
    private TextView tv_orderStatus;
    private TextView tv_orderPlaceDate;
    private TextView tv_deliveryDate;
    private TextView tv_orderId;
    private Button btn_deliverOrder;
    private Button btn_dispatchOrder;
    private ListView listView;
    private LinearLayout ly_orderStatus;

    private String order_id;
    private Order order;

    private Activity context;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_driver_order_details);
        context = this;

        ImageView iv_infoSupplier;
        ImageView iv_back;
        iv_back = findViewById(R.id.iv_back);
        tv_orderId = findViewById(R.id.tv_orderId);
        tv_deliveryDate = findViewById(R.id.tv_deliveryDate);
        tv_orderPlaceDate = findViewById(R.id.tv_orderPlaceDate);
        ly_orderStatus = findViewById(R.id.ly_orderStatus);
        tv_orderStatus = findViewById(R.id.tv_orderStatus);
        tv_supplierName = findViewById(R.id.tv_supplierName);
        iv_infoSupplier = findViewById(R.id.iv_infoSupplier);
        listView = findViewById(R.id.listView);
        btn_dispatchOrder = findViewById(R.id.btn_dispatchOrder);
        btn_deliverOrder = findViewById(R.id.btn_deliverOrder);

        //Get the order id of the order object selected in the previous page
        order_id = getIntent().getStringExtra("Order_id");

        getOrders();

        //Supplier Button
        iv_infoSupplier.setOnClickListener(v -> {
            Intent intent = new Intent();
            intent.setClass(context, SupplierDetailsActivity.class);
            intent.putExtra("Supplier_id", order.getSupplierId());//store the trip id within the "Supplier_id" key
            startActivity(intent);
        });

        //Dispatch Button
        btn_dispatchOrder.setOnClickListener(v ->
            /**
             * Send a PUT method "update order to "in-transit" by order Id" request to the server
             */
            MyHttpUtil.getWithToken(MyUrlConfig.order + "/" + order_id + "/in-transit", "PUT", new MyHttpCallbackUtil() {
                @Override
                public void onSuccess(String data) {
                    Response<Order> result = MyJsonUtil.fromJson(data, new TypeToken<Response<Order>>() {
                    }.getType());
                    if (result != null) {
                        MyToastUtil.show(context, result.getMsg());
                        order = result.getData();
                        updateOrder();
                        btn_dispatchOrder.setVisibility(View.GONE);
                        btn_deliverOrder.setVisibility(View.VISIBLE);
                    }
                }

                @Override
                public void onFailure(String data) {
                    FailureResponse<String> result = MyJsonUtil.fromJson(data, new TypeToken<FailureResponse<String>>() {
                    }.getType());
                    MyToastUtil.show(context, result.getMsg());
                }
            })
        );

        //Deliver Button
        btn_deliverOrder.setOnClickListener(v ->
            /**
             * Send a PUT method "update order to "deliver" by order Id" request to the server
             */
            MyHttpUtil.getWithToken(MyUrlConfig.order + "/" + order_id + "/deliver", "PUT", new MyHttpCallbackUtil() {
                @Override
                public void onSuccess(String data) {
                    Response<Order> result = MyJsonUtil.fromJson(data, new TypeToken<Response<Order>>() {
                    }.getType());
                    if (result != null) {
                        MyToastUtil.show(context, result.getMsg());
                        order = result.getData();
                        updateOrder();
                        btn_deliverOrder.setVisibility(View.GONE);
                    }
                }

                @Override
                public void onFailure(String data) {
                    FailureResponse<String> result = MyJsonUtil.fromJson(data, new TypeToken<FailureResponse<String>>() {
                    }.getType());
                    MyToastUtil.show(context, result.getMsg());
                }
            })
        );
        //Back Button
        iv_back.setOnClickListener(v -> finish());
    }

    /**
     * Send a GET method "get driver order by order Id" request to the server
     */
    private void getOrders() {
        MyHttpUtil.getWithToken(MyUrlConfig.order + "/" + order_id, "GET", new MyHttpCallbackUtil() {
            @Override
            public void onSuccess(String data) {
                Response<Order> result = MyJsonUtil.fromJson(data, new TypeToken<Response<Order>>() {
                }.getType());
                if (result != null) {
                    order = result.getData();

                    updateOrder();

                    tv_supplierName.setText(order.getSupplierName());
                    List<Inventory> items = order.getItems();

                    /**
                     * Display the all items of the order in a ListView
                     */
                    MyAdapter<Inventory> adapter = new MyAdapter<Inventory>(context, items, R.layout.item_order_items) {
                        @Override
                        public void convert(ViewHolder helper, Inventory inventory, int position) {
                            helper.setText(R.id.tv_inventoryItemName, inventory.getItemName());
                            helper.setText(R.id.tv_expiryDate, inventory.getExpiryDate());
                            helper.setText(R.id.tv_quantity, inventory.getQuantity() + "");
                        }
                    };
                    listView.setAdapter(adapter);
                }
            }

            @Override
            public void onFailure(String data) {
                FailureResponse<String> result = MyJsonUtil.fromJson(data, new TypeToken<FailureResponse<String>>() {
                }.getType());
                MyToastUtil.show(context, result.getMsg());
            }
        });
    }

    /**
     * Update order status
     */
    private void updateOrder() {
        String orderId = "Order ID: " + order.getId();
        tv_orderId.setText(orderId);
        tv_deliveryDate.setText(order.getDeliveryDate());
        tv_orderPlaceDate.setText(order.getPlacedDate());
        String status;
        int approved = 1;
        int dispatched = 2;
        if (order.getStatus() == approved) {
            status = "Approved";
            ly_orderStatus.setVisibility(View.GONE);
            btn_dispatchOrder.setVisibility(View.VISIBLE);
        } else if (order.getStatus() == dispatched) {
            status = "Dispatched";
            btn_deliverOrder.setVisibility(View.VISIBLE);
        } else {
            status = "Delivered";
        }
        tv_orderStatus.setText(status);
    }
}