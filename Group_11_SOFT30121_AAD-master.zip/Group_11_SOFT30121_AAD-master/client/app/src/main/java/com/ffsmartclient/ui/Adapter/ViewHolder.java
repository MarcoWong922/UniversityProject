/*
 * NTU Wenjia Geng (c) All rights reserved
 * None of this code can be reproduced or partly re-used without the permission
 * from Wenjia Geng (wenjia.geng2020@my.ntu.ac.uk).
 */
package com.ffsmartclient.ui.adapter;

import android.content.Context;
import android.util.SparseArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.DrawableRes;

/**
 * ViewHolder class， For optimising the ListView and GridView
 * @author Wenjia Geng
 * Reference: https://www.javatips.net/api/BaseAndroidLibs-master/src/com/jmheart/adapter/ViewHolder.java
 */

public class ViewHolder {

    private final SparseArray<View> mViews;
    private View mConvertView;

    /**
     * Construct a ViewHolder object using the passed in parameters
     * @param context current state of activity
     * @param parent Parent view of the current view
     * @param layoutId Resource id of the layout file
     */
    private ViewHolder(Context context, ViewGroup parent, int layoutId)
    {
        this.mViews = new SparseArray<>();
        mConvertView = LayoutInflater.from(context).inflate(layoutId, parent,false);
        mConvertView.setTag(this);
    }

    /**
     * Get a ViewHolder object
     * @param context current state of activity
     * @param convertView Views that can be reused for the single item
     * @param parent Parent view of the current view
     * @param layoutId Resource id of the layout file
     * @return Returns the tag of the ViewHolder object in the mConvertView
     */
    public static ViewHolder get(Context context, View convertView, ViewGroup parent, int layoutId)
    {
        if (convertView == null){
            //创建ViewHolder对象 ,并将View缓存
            return new ViewHolder(context, parent, layoutId);
        }
        return (ViewHolder)convertView.getTag();
    }

    /**
     * Get the view in the ViewHolder object that can be reused for the single item
     * @return ConvertView View of single item
     */
    public View getConvertView()
    {
        return mConvertView;
    }


    /**
     * Get the view of the specified item in the ViewHolder object by the resource ID of the view,
     * or add a view to it if there is no view
     * @param viewId Resource ID of the view
     * @return view object
     */
    public <T extends View> T getView(int viewId){

        View view = mViews.get(viewId);
        if (view == null){
            view = mConvertView.findViewById(viewId);
            mViews.put(viewId, view);
        }
        return (T)view;
    }

    /**
     * Find the respective view by viewId and set the text content for it
     * @param viewId Resource ID of the view
     * @param text Text content
     * @return Current ViewHolder object
     */
    public ViewHolder setText(int viewId, String text)
    {
        TextView view = getView(viewId);
        if (view != null) {
            view.setText(text);
        }
        return this;
    }

    /**
     * Find the respective view by viewId and set the image for it
     * @param viewId Resource ID of the view
     * @param drawableId Resource id of the image in the Drawable folder
     * @return Current ViewHolder object
     */
    public ViewHolder setImageResource(int viewId,@DrawableRes int drawableId)
    {
        ImageView view;
        view = getView(viewId);
        view.setImageResource(drawableId);
        return this;
    }

}
