/*
 * NTU Wenjia Geng (c) All rights reserved
 * None of this code can be reproduced or partly re-used without the permission
 * from Wenjia Geng (wenjia.geng2020@my.ntu.ac.uk).
 */
package com.ffsmartclient.ui.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.ffsmartclient.model.Inventory;
import com.ffsmartclient.model.InventoryChange;
import com.ffsmartclient.R;
import com.ffsmartclient.utils.httputils.FailureResponse;
import com.ffsmartclient.utils.httputils.MyHttpCallbackUtil;
import com.ffsmartclient.utils.httputils.MyHttpUtil;
import com.ffsmartclient.utils.httputils.MyUrlConfig;
import com.ffsmartclient.utils.httputils.Response;
import com.ffsmartclient.utils.MyJsonUtil;
import com.ffsmartclient.utils.MyToastUtil;
import com.ffsmartclient.ui.adapter.MyAdapter;
import com.ffsmartclient.ui.adapter.ViewHolder;
import com.google.gson.reflect.TypeToken;

import java.util.ArrayList;
import java.util.List;

/**
 * Inventory Item Change Details Page Controller
 *
 * @author Wenjia Geng
 */

public class InventoryChangeDetailsActivity extends AppCompatActivity {

    private ListView listView;
    private TextView tv_inventoryChangeId;
    private TextView tv_operation;
    private TextView tv_date;
    private TextView tv_userId;
    private TextView tv_userName;

    private List<Inventory> items = new ArrayList<>();

    private String userName;
    private InventoryChange inventoryChange;

    private Activity context;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory_change_details);
        context = this;

        ImageView iv_back;
        iv_back = findViewById(R.id.iv_back);
        tv_inventoryChangeId = findViewById(R.id.tv_inventoryChangeId);
        tv_operation = findViewById(R.id.tv_operation);
        tv_date = findViewById(R.id.tv_date);
        tv_userId = findViewById(R.id.tv_userId);
        tv_userName = findViewById(R.id.tv_userName);

        listView = findViewById(R.id.listView);

        //Get the supplier id of the supplier object selected in the previous page
        String changeId = getIntent().getStringExtra("Change_id");

        /**
         * Send a GET method "get inventory change by change Id" request to the server
         */
        MyHttpUtil.getWithToken(MyUrlConfig.inventory + "/change-history/"+changeId, "GET", new MyHttpCallbackUtil() {
            @Override
            public void onSuccess(String data) {
                Response<InventoryChange> result = MyJsonUtil.fromJson(data, new TypeToken<Response<InventoryChange>>(){}.getType());
                if(result != null){
                    inventoryChange = result.getData();
                    String changeId = "Inventory Change ID: "+inventoryChange.getId();
                    tv_inventoryChangeId.setText(changeId);
                    String operation;
                    if(inventoryChange.getOperation() == 0){
                        operation = "Remove";
                    }else{
                        operation = "Insert";
                    }
                    tv_operation.setText(operation);
                    tv_date.setText(inventoryChange.getDate());
                    tv_userId.setText(inventoryChange.getUserId());
                    items = inventoryChange.getItems();

                    //Update User Name
                    if(!"".equals(inventoryChange.getUserId().trim())){
                        MyHttpUtil.getWithToken(MyUrlConfig.user + "/"+inventoryChange.getUserId()+"/name", "GET", new MyHttpCallbackUtil() {
                            @Override
                            public void onSuccess(String data) {
                                Response<String> result = MyJsonUtil.fromJson(data, new TypeToken<Response<String>>(){}.getType());
                                if(result != null){
                                    userName = result.getData();
                                    tv_userName.setText(userName);
                                }
                            }

                            @Override
                            public void onFailure(String data){
                                FailureResponse<String> result = MyJsonUtil.fromJson(data, new TypeToken<FailureResponse<String>>(){}.getType());
                                MyToastUtil.show(context, result.getMsg());
                            }
                        });
                    }

                    /**
                     * Display the items that the supplier provided in a ListView
                     */
                    MyAdapter<Inventory> adapter = new MyAdapter<Inventory>(context, items, R.layout.item_inventory_change_items) {
                        @Override
                        public void convert(ViewHolder helper, Inventory item, int position) {
                            helper.setText(R.id.tv_inventoryItemName, item.getItemName());
                            helper.setText(R.id.tv_itemQuantity, item.getQuantity()+"");
                        }
                    };
                    listView.setAdapter(adapter);
                }
            }

            @Override
            public void onFailure(String data){
                FailureResponse<String> result = MyJsonUtil.fromJson(data, new TypeToken<FailureResponse<String>>(){}.getType());
                MyToastUtil.show(context, result.getMsg());
            }
        });

        iv_back.setOnClickListener(v -> finish());
    }

}