/*
 * NTU Wenjia Geng (c) All rights reserved
 * None of this code can be reproduced or partly re-used without the permission
 * from Wenjia Geng (wenjia.geng2020@my.ntu.ac.uk).
 */
package com.ffsmartclient.model;

import java.util.List;

/**
 * Inventory Change Data Model
 *
 * @author Wenjia Geng
 */

public class InventoryChange {

    private String id;

    private String userId;

    private List<Inventory> items;

    private int operation;

    private String date;

    public InventoryChange(String id, String userId, List<Inventory> items, int operation, String date) {
        this.id = id;
        this.userId = userId;
        this.items = items;
        this.operation = operation;
        this.date = date;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public List<Inventory> getItems() {
        return items;
    }

    public void setItems(List<Inventory> items) {
        this.items = items;
    }

    public int getOperation() {
        return operation;
    }

    public void setOperation(int operation) {
        this.operation = operation;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }
}
