/*
 * NTU Wenjia Geng (c) All rights reserved
 * None of this code can be reproduced or partly re-used without the permission
 * from Wenjia Geng (wenjia.geng2020@my.ntu.ac.uk).
 */
package com.ffsmartclient.ui.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;

import com.ffsmartclient.R;
import com.ffsmartclient.utils.httputils.FailureResponse;
import com.ffsmartclient.utils.httputils.MyHttpCallbackUtil;
import com.ffsmartclient.utils.httputils.MyHttpUtil;
import com.ffsmartclient.utils.httputils.MyUrlConfig;
import com.ffsmartclient.utils.httputils.Response;
import com.ffsmartclient.utils.MyJsonUtil;
import com.ffsmartclient.utils.MyToastUtil;
import com.ffsmartclient.ui.adapter.MyAdapter;
import com.ffsmartclient.ui.adapter.ViewHolder;
import com.google.gson.reflect.TypeToken;

import java.util.List;

/**
 * Report Page Controller
 *
 * @author Wenjia Geng
 */

public class ReportsActivity extends AppCompatActivity {

    private ListView listView;
    private List<String> reportNames;

    private Activity context;
    private MyAdapter<String> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reports);
        context = this;

        ImageView iv_back;
        Button btn_newReport;
        iv_back = findViewById(R.id.iv_back);
        listView = findViewById(R.id.listView);
        btn_newReport = findViewById(R.id.btn_newReport);

        getAllReports();

        //New Report Button
        btn_newReport.setOnClickListener(v -> generateNewReport());

        //Back Button
        iv_back.setOnClickListener(v -> finish());
    }

    /**
     * Generate New Report
     */
    private void generateNewReport() {
        /**
         * Send a POST method "Generate New Report" request to the server
         */
        MyHttpUtil.getWithToken(MyUrlConfig.report, "POST", new MyHttpCallbackUtil() {
            @Override
            public void onSuccess(String data) {
                Response<List<String>> result = MyJsonUtil.fromJson(data, new TypeToken<Response<List<String>>>() {
                }.getType());
                MyToastUtil.show(context, result.getMsg());
                getAllReports();
            }

            @Override
            public void onFailure(String data) {
                FailureResponse<String> result = MyJsonUtil.fromJson(data, new TypeToken<FailureResponse<String>>() {
                }.getType());
                MyToastUtil.show(context, result.getMsg());
            }
        });
    }

    /**
     * Get All reports
     */
    private void getAllReports() {
        /**
         * Send a GET method "get all reports" request to the server
         */
        MyHttpUtil.getWithToken(MyUrlConfig.report, "GET", new MyHttpCallbackUtil() {
            @Override
            public void onSuccess(String data) {
                Response<List<String>> result = MyJsonUtil.fromJson(data, new TypeToken<Response<List<String>>>() {
                }.getType());
                if (result != null) {
                    reportNames = result.getData();
                    /**
                     * Display the all orders in a ListView
                     */
                    adapter = new MyAdapter<String>(context, reportNames, R.layout.item_reports) {
                        @Override
                        public void convert(ViewHolder helper, String reportName, int position) {
                            helper.setText(R.id.tv_reportName, reportName);
                            /**
                             * Check the order details
                             */
                            helper.getView(R.id.iv_infoReport).setOnClickListener(v -> {
                                Intent intent = new Intent();
                                intent.setClass(context, ReportDetailsActivity.class);
                                intent.putExtra("Report_Name", reportName);
                                startActivity(intent);
                            });
                        }
                    };
                    listView.setAdapter(adapter);
                }
            }

            @Override
            public void onFailure(String data) {
                MyToastUtil.show(context, "Failed");
            }
        });
    }
}