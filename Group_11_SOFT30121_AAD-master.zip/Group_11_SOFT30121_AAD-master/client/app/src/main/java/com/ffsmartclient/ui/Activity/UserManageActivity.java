/*
 * NTU Wenjia Geng (c) All rights reserved
 * None of this code can be reproduced or partly re-used without the permission
 * from Wenjia Geng (wenjia.geng2020@my.ntu.ac.uk).
 */
package com.ffsmartclient.ui.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Base64;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.resource.bitmap.CircleCrop;
import com.ffsmartclient.model.User;
import com.ffsmartclient.R;
import com.ffsmartclient.utils.httputils.FailureResponse;
import com.ffsmartclient.utils.httputils.MyHttpCallbackUtil;
import com.ffsmartclient.utils.httputils.MyHttpUtil;
import com.ffsmartclient.utils.httputils.MyUrlConfig;
import com.ffsmartclient.utils.httputils.Response;
import com.ffsmartclient.utils.MyJsonUtil;
import com.ffsmartclient.utils.MyToastUtil;
import com.google.gson.reflect.TypeToken;

/**
 * User Account Management Page Controller
 *
 * @author Wenjia Geng
 */

public class UserManageActivity extends AppCompatActivity {

    private TextView tv_userId;
    private TextView tv_firstName;
    private TextView tv_lastName;
    private TextView tv_email;
    private Button btn_roleUpdate;
    private RadioButton radio_driver;
    private RadioButton radio_chef;
    private RadioButton radio_headchef;

    private Activity context;
    private User user;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_manage);

        context = this;

        String manage_userId;

        ImageView iv_back;
        Button btn_userDelete;
        iv_back = findViewById(R.id.iv_back);
        tv_userId = findViewById(R.id.tv_userId);
        tv_firstName = findViewById(R.id.tv_firstName);
        tv_lastName = findViewById(R.id.tv_lastName);
        tv_email = findViewById(R.id.tv_email);
        radio_driver = findViewById(R.id.radio_driver);
        radio_chef = findViewById(R.id.radio_chef);
        radio_headchef = findViewById(R.id.radio_headchef);
        btn_roleUpdate = findViewById(R.id.btn_roleUpdate);
        btn_userDelete = findViewById(R.id.btn_userDelete);
        btn_userDelete.setBackgroundColor(Color.parseColor("#a00000"));
        //Get the inventory id of the inventory object selected in the previous page
        manage_userId = getIntent().getStringExtra("Manage_userId");

        /**
         * Send a GET method "get user by user Id" request to the server
         */
        MyHttpUtil.getWithToken(MyUrlConfig.user + "/" + manage_userId, "GET", new MyHttpCallbackUtil() {
            @Override
            public void onSuccess(String data) {
                Response<User> result = MyJsonUtil.fromJson(data, new TypeToken<Response<User>>() {
                }.getType());
                if (result != null) {
                    user = result.getData();
                    tv_userId.setText("User ID: " + user.getId());
                    Bitmap bitmap;
                    try {
                        byte[] bytes = Base64.decode(user.getAvatar(), Base64.DEFAULT);
                        bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
                    } catch (Exception e) {
                        bitmap = null;
                    }
                    Glide.with(context)
                            .load(bitmap)
                            .error(R.drawable.avatar)
                            .transform(new CircleCrop())
                            .into((ImageView) findViewById(R.id.iv_avatar));

                    tv_firstName.setText(user.getFirstName());
                    tv_lastName.setText(user.getLastName());
                    tv_email.setText(user.getEmail());
                    int userRole = user.getRole();
                    if (userRole == 0) {
                        radio_driver.setChecked(true);
                    } else if (userRole == 1) {
                        radio_chef.setChecked(true);
                    } else {
                        radio_headchef.setChecked(true);
                    }
                    //Update user role
                    btn_roleUpdate.setOnClickListener(v -> updateUserRole());
                }
            }

            @Override
            public void onFailure(String data) {
                FailureResponse<String> result = MyJsonUtil.fromJson(data, new TypeToken<FailureResponse<String>>() {
                }.getType());
                MyToastUtil.show(context, result.getMsg());
            }
        });

        //Delete User Account
        btn_userDelete.setOnClickListener(v -> deleteUser());

        //Back Button
        iv_back.setOnClickListener(v -> finish());
    }

    /**
     * Delete User Account
     */
    private void deleteUser() {
        /**
         * Send a DELETE method "delete user by user Id" request to the server
         */
        MyHttpUtil.getWithToken(MyUrlConfig.user + "/" + user.getId(), "DELETE", new MyHttpCallbackUtil() {
            @Override
            public void onSuccess(String data) {
                MyToastUtil.show(context, "Success");
                finish();
            }

            @Override
            public void onFailure(String data) {
                MyToastUtil.show(context, "Failed");
            }
        });
    }

    /**
     * Update user role
     */
    private void updateUserRole() {
        //Check if user role is selected
        if (!radio_driver.isChecked() && !radio_chef.isChecked() && !radio_headchef.isChecked()) {
            MyToastUtil.show(context, "Please select role");
            return;
        }
        //assign role value
        int role = 0;
        if (radio_driver.isChecked()) {
            role = 0;
        } else if (radio_chef.isChecked()) {
            role = 1;
        } else if (radio_headchef.isChecked()) {
            role = 2;
        }

        user.setRole(role);
        /**
         * Send a POST method "update user by user Id" request to the server
         */
        MyHttpUtil.postWithToken(MyUrlConfig.user + "/" + user.getId(), user, "PUT", new MyHttpCallbackUtil() {
            @Override
            public void onSuccess(String data) {
                Response<User> result = MyJsonUtil.fromJson(data, new TypeToken<Response<User>>() {
                }.getType());
                MyToastUtil.show(context, result.getMsg());
                if (result != null) {
                    user = result.getData();
                    int userRole = user.getRole();
                    if (userRole == 0) {
                        radio_driver.setChecked(true);
                    } else if (userRole == 1) {
                        radio_chef.setChecked(true);
                    } else {
                        radio_headchef.setChecked(true);
                    }
                }
            }

            @Override
            public void onFailure(String data) {
                FailureResponse<String> result = MyJsonUtil.fromJson(data, new TypeToken<FailureResponse<String>>() {
                }.getType());
                MyToastUtil.show(context, result.getMsg());
            }
        });
    }
}