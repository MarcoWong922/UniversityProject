/*
 * NTU Wenjia Geng (c) All rights reserved
 * None of this code can be reproduced or partly re-used without the permission
 * from Wenjia Geng (wenjia.geng2020@my.ntu.ac.uk).
 */
package com.ffsmartclient.ui.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.blankj.utilcode.util.SPUtils;
import com.ffsmartclient.model.LoginCredential;
import com.ffsmartclient.model.LoginToken;
import com.ffsmartclient.model.User;
import com.ffsmartclient.R;
import com.ffsmartclient.utils.httputils.FailureResponse;
import com.ffsmartclient.utils.httputils.MyHttpCallbackUtil;
import com.ffsmartclient.utils.httputils.MyHttpUtil;
import com.ffsmartclient.utils.httputils.MyUrlConfig;
import com.ffsmartclient.utils.httputils.Response;
import com.ffsmartclient.utils.MyJsonUtil;
import com.ffsmartclient.utils.MyToastUtil;
import com.google.gson.reflect.TypeToken;

import java.util.regex.Pattern;

/**
 * Login Page Controller
 *
 * @author Wenjia Geng
 */

public class LoginActivity extends AppCompatActivity {

    private LoginActivity context;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        context = this;

        Button btn_login;
        TextView tv_sign_up;
        EditText edit_email;
        EditText edit_password;
        edit_email = findViewById(R.id.edit_email);
        edit_password = findViewById(R.id.edit_password);
        btn_login = findViewById(R.id.btn_login);
        tv_sign_up = findViewById(R.id.tv_sign_up);

        /**
         * Enter the user credentials(Email & Password) to login
         */
        btn_login.setOnClickListener(v -> {
            String email = edit_email.getText().toString();
            String password = edit_password.getText().toString();

            //Check the format of the email
            boolean emailCheckPass = Pattern.matches("^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,6}$", email);
            if (!emailCheckPass) {
                MyToastUtil.show(context, "Wrong Email Format");
                return;
            }

            //Check the format of the password
            //The password cannot be made up of all numbers or all alphabets.
            //The password should be a mixture of 6 to 10 digits or letters.
            boolean passwordCheckPass = Pattern.matches("^(?!\\d+$)(?![a-zA-Z]+$)[0-9A-Za-z]{6,10}$", password);
            if (!passwordCheckPass) {
                MyToastUtil.show(context, "Wrong Password Format");
                return;
            }

            LoginCredential login = new LoginCredential();
            login.setEmail(email);
            login.setPassword(password);

            /**
             * Send a POST method "login" request to the server
             */
            MyHttpUtil.post(MyUrlConfig.user + "/login", login, "POST", new MyHttpCallbackUtil() {
                @Override
                public void onSuccess(String data) {
                    //When the request successfully returns Json String data, convert the json data to the user type object
                    Response<LoginToken> result = MyJsonUtil.fromJson(data, new TypeToken<Response<LoginToken>>() {
                    }.getType());
                    MyToastUtil.show(context, result.getMsg());
                    if (result.getData() != null) {
                        LoginToken resultToken = result.getData();
                        //Save user information if login is successful
                        String token = resultToken.getToken();
                        User loginUser = resultToken.getUser();

                        SPUtils.getInstance().put("user_json", data);//Store login user information with "user_json" key
                        SPUtils.getInstance().put(loginUser.getId(), token);//Save token with user ID
                        Intent intent = new Intent();
                        //Go to home page
                        intent.setClass(context, MainActivity.class);
                        startActivity(intent);
                        //Close the current page
                        finish();
                    }
                }

                @Override
                public void onFailure(String data) {
                    FailureResponse<String> result = MyJsonUtil.fromJson(data, new TypeToken<FailureResponse<String>>() {
                    }.getType());
                    MyToastUtil.show(context, result.getMsg());
                }
            });
        });

        /**
         * Go to login page
         */
        tv_sign_up.setOnClickListener(v -> {
            Intent intent = new Intent();
            intent.setClass(context, RegisterActivity.class);
            startActivity(intent);
        });
    }
}