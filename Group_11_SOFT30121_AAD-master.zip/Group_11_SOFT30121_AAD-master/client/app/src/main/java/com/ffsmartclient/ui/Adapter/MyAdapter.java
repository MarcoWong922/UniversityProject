/*
 * NTU Wenjia Geng (c) All rights reserved
 * None of this code can be reproduced or partly re-used without the permission
 * from Wenjia Geng (wenjia.geng2020@my.ntu.ac.uk).
 */
package com.ffsmartclient.ui.adapter;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;

import java.util.List;

/**
 * For displaying the retrieved data in a ListView or GridView
 * @param <T> The data type of the content to be displayed in the ListView or GridView
 * @author Wenjia Geng
 * Reference: https://www.javatips.net/api/BaseAndroidLibs-master/src/com/jmheart/adapter/CommonAdapter.java
 */

public abstract class MyAdapter<T> extends BaseAdapter {

    protected Context mContext;
    protected List<T> mDatas;
    protected final int mItemLayoutId;

    /**
     * Construct an Adapter for the ListView or GridView
     * @param context      current state of activity
     * @param mDatas       Collection of data to be displayed
     * @param itemLayoutId Sub-layout file's resource id
     */
    protected MyAdapter(Context context, List<T> mDatas, int itemLayoutId) {
        this.mContext = context;
        this.mDatas = mDatas;
        this.mItemLayoutId = itemLayoutId;
    }

    //Override the methods in the BaseAdapter parent class
    @Override
    public int getCount() {
        return mDatas.size();
    }

    @Override
    public T getItem(int position) {
        return mDatas.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    /**
     * Creates and returns a list view of the specified location
     * @param position Position of the current view
     * @param convertView Views that can be reused for the single item
     * @param parent Parent view of the current view
     * @return view in the viewHolder object
     */
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        //Get the view from the ViewHolder, or create a ViewHolder object if it is empty
        final ViewHolder viewHolder = getViewHolder(convertView, parent);
        //Pass in the viewHolder object and the data of the list item at the current position
        // to convert the data in to a view
        convert(viewHolder, getItem(position), position);


        return viewHolder.getConvertView();
    }

    /**
     * Abstract method for getting the changed part of the getView method
     * @param helper ViewHolder object
     * @param item   Bean object
     * @param position Position of the current view
     */
    public abstract void convert(ViewHolder helper, T item, int position);

    /**
     * Get the view in the ViewHolder object
     * @param convertView Views that can be reused for the single item
     * @param parent Parent view of the current view
     * @return ViewHolder object
     */
    private ViewHolder getViewHolder(View convertView, ViewGroup parent) {
        return ViewHolder.get(mContext, convertView, parent, mItemLayoutId);
    }

}

