/*
 * NTU Wenjia Geng (c) All rights reserved
 * None of this code can be reproduced or partly re-used without the permission
 * from Wenjia Geng (wenjia.geng2020@my.ntu.ac.uk).
 */
package com.ffsmartclient.ui.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;

import com.ffsmartclient.common.LoginSession;
import com.ffsmartclient.model.User;
import com.ffsmartclient.R;

/**
 * Launcher Page Controller
 *
 * @author Wenjia Geng
 */

public class LauncherActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_launcher);

        LauncherActivity context = this;

        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            //Get login use information in the shared preference
            User user = LoginSession.getUser();
            Intent intent = new Intent();
            //user has logged in
            if (user != null) {
                intent.setClass(context, MainActivity.class);
            }
            //user has not logged in
            else {
                intent.setClass(context, LoginActivity.class);
            }
            startActivity(intent);
            finish();
        }, 1500);
    }
}