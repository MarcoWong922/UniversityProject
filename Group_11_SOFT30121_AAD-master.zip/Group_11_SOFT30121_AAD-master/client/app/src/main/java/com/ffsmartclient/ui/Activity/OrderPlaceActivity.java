/*
 * NTU Wenjia Geng (c) All rights reserved
 * None of this code can be reproduced or partly re-used without the permission
 * from Wenjia Geng (wenjia.geng2020@my.ntu.ac.uk).
 */
package com.ffsmartclient.ui.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.blankj.utilcode.util.SPUtils;
import com.ffsmartclient.common.LoginSession;
import com.ffsmartclient.model.Inventory;
import com.ffsmartclient.model.Item;
import com.ffsmartclient.model.Order;
import com.ffsmartclient.model.Supplier;
import com.ffsmartclient.R;
import com.ffsmartclient.utils.httputils.FailureResponse;
import com.ffsmartclient.utils.httputils.MyHttpCallbackUtil;
import com.ffsmartclient.utils.httputils.MyHttpUtil;
import com.ffsmartclient.utils.httputils.MyUrlConfig;
import com.ffsmartclient.utils.httputils.Response;
import com.ffsmartclient.utils.MyJsonUtil;
import com.ffsmartclient.utils.MyLogUtil;
import com.ffsmartclient.utils.MyToastUtil;
import com.ffsmartclient.ui.adapter.MyAdapter;
import com.ffsmartclient.ui.adapter.ViewHolder;
import com.ffsmartclient.ui.dialog.SupplierItemSelectDialog;
import com.ffsmartclient.ui.dialog.SupplierSelectDialog;
import com.google.gson.reflect.TypeToken;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;
import java.util.regex.Pattern;

/**
 * Order Place Page Controller
 *
 * @author Wenjia Geng
 */

public class OrderPlaceActivity extends AppCompatActivity {

    String template = "yyyy-MM-dd";
    Locale locale = Locale.UK;
    SimpleDateFormat format = new SimpleDateFormat(template, locale);

    private TextView tv_itemSelect;
    private TextView tv_supplierSelect;
    private EditText edit_quantity;
    private EditText edit_deliveryDate;

    private Item selectItem;
    private Supplier selectSupplier;
    private List<Inventory> items = new ArrayList<>();

    private Activity context;

    private MyAdapter<Inventory> myAdapter;

    private static final String ORDER_INSERT_INVENTORY = "OrderInsertInventory";
    private static final String ORDER_SUPPLIER = "OrderSupplier";
    private static final String ORDER_DELIVERY_DATE = "OrderDeliveryDate";

    private static final String NOTIFY_ENTER_DELIVERY_DATE = "Please enter the delivery date";

    private Calendar rightNow = Calendar.getInstance();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_place);

        context = this;

        ImageView iv_back;
        Button btn_add;
        ListView listView;
        Button btn_orderPlace;

        iv_back = findViewById(R.id.iv_back);
        tv_supplierSelect = findViewById(R.id.tv_supplierSelect);
        tv_supplierSelect.getPaint().setFlags(Paint.UNDERLINE_TEXT_FLAG);
        edit_deliveryDate = findViewById(R.id.edit_deliveryDate);
        rightNow.add(Calendar.DAY_OF_YEAR, 7);
        edit_deliveryDate.setText(format.format(rightNow.getTime()));
        tv_itemSelect = findViewById(R.id.tv_itemSelect);
        tv_itemSelect.getPaint().setFlags(Paint.UNDERLINE_TEXT_FLAG);
        edit_quantity = findViewById(R.id.edit_quantity);
        btn_add = findViewById(R.id.btn_add);
        btn_add.setBackgroundColor(Color.parseColor("#a00000"));
        listView = findViewById(R.id.listView);

        btn_orderPlace = findViewById(R.id.btn_orderPlace);

        //Oder Item List
        String listInventoryItemsJson = SPUtils.getInstance().getString(LoginSession.getUid() + ORDER_INSERT_INVENTORY);
        if (!"".equals(listInventoryItemsJson)) {
            items = MyJsonUtil.fromJson(listInventoryItemsJson, new TypeToken<List<Inventory>>() {
            }.getType());
        }
        //Supplier obj
        String orderSupplierJson = SPUtils.getInstance().getString(LoginSession.getUid() + ORDER_SUPPLIER);
        if (!orderSupplierJson.equals("null") && orderSupplierJson != null && !orderSupplierJson.isEmpty()) {
            selectSupplier = MyJsonUtil.fromJson(orderSupplierJson, new TypeToken<Supplier>() {
            }.getType());
            tv_supplierSelect.setText(selectSupplier.getName());
        }
        //Delivery Date obj
        String orderDeliveryDateStr = SPUtils.getInstance().getString(LoginSession.getUid() + ORDER_DELIVERY_DATE);
        if (!"".equals(orderDeliveryDateStr.trim())) {
            edit_deliveryDate.setText(orderDeliveryDateStr);
        }

        /**
         * Display the added Inventory Items in the ListView
         */
        myAdapter = new MyAdapter<Inventory>(context, items, R.layout.item_added_inventory) {
            @Override
            public void convert(ViewHolder helper, Inventory inventory, int position) {
                helper.setText(R.id.tv_inventoryItemName, inventory.getItemName());
                helper.setText(R.id.tv_expiryDate, inventory.getExpiryDate());
                helper.setText(R.id.tv_insertQuantity, " " + inventory.getQuantity());
                /**
                 * Delete added item
                 */
                helper.getView(R.id.iv_deleteInventoryItem).setOnClickListener(v -> {
                    items.remove(position);
                    myAdapter.notifyDataSetChanged();
                });
            }
        };
        listView.setAdapter(myAdapter);

        //Pop-up window to Choose Available Supplier
        tv_supplierSelect.setOnClickListener(v -> selectSupplier());

        //Pop-up window to Choose Available Item from the Supplier
        tv_itemSelect.setOnClickListener(v -> selectItem());

        //Add New Item to Order
        btn_add.setOnClickListener(v -> addNewItem());

        //Submit Order
        btn_orderPlace.setOnClickListener(v -> placeOrder());

        //Back Button
        iv_back.setOnClickListener(v -> {
            //Item list
            SPUtils.getInstance().put(LoginSession.getUid() + ORDER_INSERT_INVENTORY, MyJsonUtil.toJson(items));
            //Supplier obj
            SPUtils.getInstance().put(LoginSession.getUid() + ORDER_SUPPLIER, MyJsonUtil.toJson(selectSupplier));
            //Delivery Date obj
            String deliveryDate = edit_deliveryDate.getText().toString();
            SPUtils.getInstance().put(LoginSession.getUid() + ORDER_DELIVERY_DATE, deliveryDate);
            finish();
        });
    }


    /**
     * Place Order
     */
    private void placeOrder() {
        String deliveryDate = edit_deliveryDate.getText().toString();

        //Check if the delivery date is empty
        //date format: year-month-day
        boolean deliveryDateCheckPass = Pattern.matches("^\\d{4}-(0[1-9]|1[0-2])-(0[1-9]|[12]\\d|3[01])$", deliveryDate);
        if ("".equals(deliveryDate.trim())) {
            MyToastUtil.show(context, NOTIFY_ENTER_DELIVERY_DATE);
            return;
        }
        //Check the format of the date
        else if (!deliveryDateCheckPass) {
            MyToastUtil.show(context, "Wrong Delivery Date Format");
            return;
        }

        String todayDate = format.format(rightNow.getTime());

        //Generate an order
        Order order = new Order(null, deliveryDate, items,
                selectSupplier.getId(), selectSupplier.getName(), null,
                0, todayDate);

        /**
         * Send a POST method "Place New Order" request to the server
         */

        MyHttpUtil.postWithToken(MyUrlConfig.order, order, "POST", new MyHttpCallbackUtil() {
            @Override
            public void onSuccess(String data) {
                //When the request successfully returns Json String data, convert the json data to the user type object
                Response<Order> result = MyJsonUtil.fromJson(data, new TypeToken<Response<Order>>() {
                }.getType());
                MyToastUtil.show(context, result.getMsg());
                //Reset InsertInventory List
                SPUtils.getInstance().put(LoginSession.getUid() + ORDER_INSERT_INVENTORY, "");
                SPUtils.getInstance().put(LoginSession.getUid() + ORDER_SUPPLIER, "");
                SPUtils.getInstance().put(LoginSession.getUid() + ORDER_DELIVERY_DATE, "");
                items.clear();
                resetOrder();
                myAdapter.notifyDataSetChanged();
            }

            @Override
            public void onFailure(String data) {
                FailureResponse<String> result = MyJsonUtil.fromJson(data, new TypeToken<FailureResponse<String>>() {
                }.getType());
                MyToastUtil.show(context, result.getMsg());

            }
        });
    }


    /**
     * Add New Item to Order
     */
    private void addNewItem() {
        String deliveryDate = edit_deliveryDate.getText().toString();
        String quantityStr = edit_quantity.getText().toString();

        //Check if the delivery date is empty
        //date format: year-month-day
        boolean deliveryDateCheckPass = Pattern.matches("^\\d{4}-(0[1-9]|1[0-2])-(0[1-9]|[12]\\d|3[01])$", deliveryDate);
        if ("".equals(deliveryDate.trim())) {
            MyToastUtil.show(context, NOTIFY_ENTER_DELIVERY_DATE);
            return;
        } else if (!deliveryDateCheckPass) {
            MyToastUtil.show(context, "Wrong Delivery Date Format");
            return;
        }

        //Check if the quantity is empty
        int quantity;
        boolean quantityCheckPass = Pattern.matches("^\\d+$", quantityStr);
        if ("".equals(quantityStr.trim())) {
            MyToastUtil.show(context, "Please enter the quantity");
            return;
        }
        //Check the age contains only digits
        else if (!quantityCheckPass) {
            MyToastUtil.show(context, "Quantity can only include digits");
            return;
        }
        //Convert string type ageStr to int type age
        else {
            quantity = Integer.parseInt(quantityStr);

        }

        // Add Created Inventory Item in to List and display
        Inventory inventoryItem = new Inventory(null, selectItem.getId(), selectItem.getName(),
                selectItem.getSupplierId(), selectItem.getSupplierName(), quantity, null);
        items.add(inventoryItem);
        resetAddItem();
        myAdapter.notifyDataSetChanged();//Notify the adapter to display new data
    }


    /**
     * Select Available Item from the Supplier
     */
    private void selectItem() {
        String supplier = tv_supplierSelect.getText().toString();
        if ("".equals(supplier.trim())) {
            MyToastUtil.show(context, "Please select a supplier");
            return;
        }
        String deliveryDate = edit_deliveryDate.getText().toString();
        if ("".equals(deliveryDate.trim())) {
            MyToastUtil.show(context, NOTIFY_ENTER_DELIVERY_DATE);
            return;
        }

        new SupplierItemSelectDialog(context, selectSupplier, new SupplierItemSelectDialog.Callback() {
            @Override
            public void onCall(Item item) { //get the item name
                MyLogUtil.log("Selected item Object: " + item);
                selectItem = item;
                if (selectItem != null) {
                    tv_itemSelect.setText(selectItem.getName());
                }
            }
        });
    }

    /**
     * Select Available Supplier
     */
    private void selectSupplier() {
        new SupplierSelectDialog(context, new SupplierSelectDialog.Callback() {
            @Override
            public void onCall(Supplier supplier) { //get the supplier name
                MyLogUtil.log("Selected Supplier Object: " + supplier);
                selectSupplier = supplier;
                if (selectSupplier != null) {
                    tv_supplierSelect.setText(selectSupplier.getName());
                    //Rest item list
                    items.clear();
                    myAdapter.notifyDataSetChanged();
                }
            }
        });
    }

    /**
     * Reset Add Item Zone
     */
    private void resetAddItem() {
        tv_itemSelect.setText("");
        edit_quantity.setText("");
    }

    /**
     * Reset Order supplier & delivery date
     */
    private void resetOrder() {
        //reset supplier
        tv_supplierSelect.setText("");
        selectSupplier = null;

        //reset delivery date
        rightNow = Calendar.getInstance();
        rightNow.add(Calendar.DAY_OF_YEAR, 7);
        edit_deliveryDate.setText(format.format(rightNow.getTime()));
    }
}