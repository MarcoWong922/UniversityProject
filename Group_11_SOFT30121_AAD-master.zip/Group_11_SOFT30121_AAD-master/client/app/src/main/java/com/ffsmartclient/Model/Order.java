/*
 * NTU Wenjia Geng (c) All rights reserved
 * None of this code can be reproduced or partly re-used without the permission
 * from Wenjia Geng (wenjia.geng2020@my.ntu.ac.uk).
 */
package com.ffsmartclient.model;

import java.util.List;

/**
 * Order Data Model
 *
 * @author Wenjia Geng
 */

public class Order {

    private String id;

    private String deliveryDate;

    private List<Inventory> items;

    private String supplierId;

    private String supplierName;

    private String driverId;

    private int status;

    private String placedDate;

    public Order(String id, String deliveryDate, List<Inventory> items, String supplierId, String supplierName, String driverId, int status, String placedDate) {
        this.id = id;
        this.deliveryDate = deliveryDate;
        this.items = items;
        this.supplierId = supplierId;
        this.supplierName = supplierName;
        this.driverId = driverId;
        this.status = status;
        this.placedDate = placedDate;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getDeliveryDate() {
        return deliveryDate;
    }

    public void setDeliveryDate(String deliveryDate) {
        this.deliveryDate = deliveryDate;
    }

    public List<Inventory> getItems() {
        return items;
    }

    public void setItems(List<Inventory> items) {
        this.items = items;
    }

    public String getSupplierId() {
        return supplierId;
    }

    public void setSupplierId(String supplierId) {
        this.supplierId = supplierId;
    }

    public String getSupplierName() {
        return supplierName;
    }

    public void setSupplierName(String supplierName) {
        this.supplierName = supplierName;
    }

    public String getDriverId() {
        return driverId;
    }

    public void setDriverId(String driverId) {
        this.driverId = driverId;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public String getPlacedDate() {
        return placedDate;
    }

    public void setPlacedDate(String placedDate) {
        this.placedDate = placedDate;
    }
}
