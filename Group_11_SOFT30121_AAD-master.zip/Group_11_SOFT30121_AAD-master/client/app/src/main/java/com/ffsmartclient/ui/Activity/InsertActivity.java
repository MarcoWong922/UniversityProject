/*
 * NTU Wenjia Geng (c) All rights reserved
 * None of this code can be reproduced or partly re-used without the permission
 * from Wenjia Geng (wenjia.geng2020@my.ntu.ac.uk).
 */
package com.ffsmartclient.ui.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;

import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.blankj.utilcode.util.SPUtils;
import com.ffsmartclient.common.LoginSession;
import com.ffsmartclient.model.Inventory;
import com.ffsmartclient.model.Item;
import com.ffsmartclient.R;
import com.ffsmartclient.utils.httputils.FailureResponse;
import com.ffsmartclient.utils.httputils.MyHttpCallbackUtil;
import com.ffsmartclient.utils.httputils.MyHttpUtil;
import com.ffsmartclient.utils.httputils.MyUrlConfig;
import com.ffsmartclient.utils.httputils.Response;
import com.ffsmartclient.utils.MyJsonUtil;
import com.ffsmartclient.utils.MyLogUtil;
import com.ffsmartclient.utils.MyToastUtil;
import com.ffsmartclient.ui.adapter.MyAdapter;
import com.ffsmartclient.ui.adapter.ViewHolder;
import com.ffsmartclient.ui.dialog.ItemSelectDialog;
import com.google.gson.reflect.TypeToken;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;
import java.util.regex.Pattern;

/**
 * Insert New Item Page Controller
 *
 * @author Wenjia Geng
 */

public class InsertActivity extends AppCompatActivity {

    String template = "yyyy-MM-dd";
    Locale locale = Locale.UK;
    SimpleDateFormat format = new SimpleDateFormat(template, locale);

    private TextView tv_itemSelect;
    private EditText edit_quantity;
    private EditText edit_expiryDate;

    private Item selectItem;
    private List<Inventory> items = new ArrayList<>();

    private Activity context;

    private MyAdapter<Inventory> myAdapter;
    private static final  String INSERT_ITEM_KEY = "InsertInventory";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_insert);

        context = this;

        ImageView iv_back;
        Button btn_add;
        ListView listView;
        Button btn_insertConfirm;
        tv_itemSelect = findViewById(R.id.tv_itemSelect);
        tv_itemSelect.getPaint().setFlags(Paint. UNDERLINE_TEXT_FLAG );
        iv_back = findViewById(R.id.iv_back);
        edit_quantity = findViewById(R.id.edit_quantity);
        edit_expiryDate = findViewById(R.id.edit_expiryDate);
        Calendar rightNow = Calendar.getInstance();
        rightNow.add(Calendar.DAY_OF_YEAR, 7);
        edit_expiryDate.setText(format.format(rightNow.getTime()));
        btn_add = findViewById(R.id.btn_add);
        btn_add.setBackgroundColor(Color.parseColor("#a00000"));

        listView = findViewById(R.id.listView);

        btn_insertConfirm = findViewById(R.id.btn_insertConfirm);

        //Reload Previous Inserted Items
        String listInventoryItemsJson = SPUtils.getInstance().getString(LoginSession.getUid()+INSERT_ITEM_KEY);
        if(!"".equals(listInventoryItemsJson)){
            items = MyJsonUtil.fromJson(listInventoryItemsJson,new TypeToken<List<Inventory>>(){}.getType());
        }

        /**
         * Display the added Inventory Items in the ListView
         */
         myAdapter = new MyAdapter<Inventory>(context, items, R.layout.item_added_inventory) {
            @Override
            public void convert(ViewHolder helper, Inventory inventory, int position) {
                helper.setText(R.id.tv_inventoryItemName, inventory.getItemName());
                helper.setText(R.id.tv_expiryDate, inventory.getExpiryDate());
                helper.setText(R.id.tv_insertQuantity, " "+inventory.getQuantity());

                /**
                 * Delete added item
                 */
                helper.getView(R.id.iv_deleteInventoryItem).setOnClickListener(v -> {
                        items.remove(position);
                        myAdapter.notifyDataSetChanged();
                });
            }
        };
        listView.setAdapter(myAdapter);

        /**
         * Pop-up window to Add Available Item
         */
        tv_itemSelect.setOnClickListener(v ->
            new ItemSelectDialog(context, new ItemSelectDialog.Callback() {
                @Override
                public void onCall(Item item) { //get the item name
                    MyLogUtil.log("Selected item Object: " +item);
                    selectItem = item;
                    if(selectItem != null){
                        tv_itemSelect.setText(selectItem.getName());
                    }
                }
            })
        );

        //Add New Item
        btn_add.setOnClickListener(v -> addNewItem());

        //Back Button
        iv_back.setOnClickListener(v -> {
            SPUtils.getInstance().put(LoginSession.getUid()+INSERT_ITEM_KEY, MyJsonUtil.toJson(items));
            finish();
        });

        //Submit Insert InventoryItems List
        btn_insertConfirm.setOnClickListener(v ->
            /**
             * Send a POST method "Insert new Inventory" request to the server
             */
            MyHttpUtil.postWithToken(MyUrlConfig.inventory + "/insert", items,"POST", new MyHttpCallbackUtil() {
                @Override
                public void onSuccess(String data) {
                    //When the request successfully returns Json String data, convert the json data to the user type object
                    Response<Inventory> result = MyJsonUtil.fromJson(data, new TypeToken<Response<Inventory>>(){}.getType());
                    MyToastUtil.show(context, result.getMsg());
                    //Reset InsertInventory List
                    SPUtils.getInstance().put(LoginSession.getUid()+INSERT_ITEM_KEY, "");
                    items.clear();
                    myAdapter.notifyDataSetChanged();
                }
                @Override
                public void onFailure(String data){
                    FailureResponse<String> result = MyJsonUtil.fromJson(data, new TypeToken<FailureResponse<String>>(){}.getType());
                    MyToastUtil.show(context, result.getMsg());
                }
            })
        );
    }

    /**
     * Add New Insert Item
     */
    private void addNewItem(){
        String quantityStr = edit_quantity.getText().toString();
        String expiryDate = edit_expiryDate.getText().toString();

        //Check if the quantity is empty
        int quantity;
        boolean quantityCheckPass = Pattern.matches("^\\d+$", quantityStr);
        if("".equals(quantityStr.trim())){
            MyToastUtil.show(context, "Please enter the quantity");
            return;
        }
        //Check the age contains only digits
        else if(!quantityCheckPass){
            MyToastUtil.show(context, "Quantity can only include digits");
            return;
        }
        //Convert string type ageStr to int type age
        else {
            quantity = Integer.parseInt(quantityStr);
        }

        //Check if the trip start date and end date is empty
        //date format: year-month-day
        boolean dateCheckPass = Pattern.matches("^\\d{4}-(0[1-9]|1[0-2])-(0[1-9]|[12]\\d|3[01])$", expiryDate);
        if("".equals(expiryDate.trim())){
            MyToastUtil.show(context, "Please enter the expiry date");
            return;
        }
        //Check the format of the date
        else if(!dateCheckPass){
            MyToastUtil.show(context, "Wrong Date Format");
            return;
        }

        //Created Inventory Item
        Inventory inventoryItem = new Inventory(null, selectItem.getId(), selectItem.getName(),
                selectItem.getSupplierId(), selectItem.getSupplierName(), quantity, expiryDate);
        items.add(inventoryItem);
        resetAddItem();

        myAdapter.notifyDataSetChanged();
    }

    /**
     * Reset Added Item Input Components
     */
    private void resetAddItem(){
        tv_itemSelect.setText("");
        edit_quantity.setText("");
        Calendar rightNow = Calendar.getInstance();
        rightNow.add(Calendar.DAY_OF_YEAR, 7);
        edit_expiryDate.setText(format.format(rightNow.getTime()));
    }

}