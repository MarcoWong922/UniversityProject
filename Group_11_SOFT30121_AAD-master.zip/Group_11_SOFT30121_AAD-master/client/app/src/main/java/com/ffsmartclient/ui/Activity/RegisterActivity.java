/*
 * NTU Wenjia Geng (c) All rights reserved
 * None of this code can be reproduced or partly re-used without the permission
 * from Wenjia Geng (wenjia.geng2020@my.ntu.ac.uk).
 */
package com.ffsmartclient.ui.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import com.blankj.utilcode.util.SPUtils;
import com.ffsmartclient.model.LoginToken;
import com.ffsmartclient.model.User;
import com.ffsmartclient.R;
import com.ffsmartclient.utils.httputils.FailureResponse;
import com.ffsmartclient.utils.httputils.MyHttpCallbackUtil;
import com.ffsmartclient.utils.httputils.MyHttpUtil;
import com.ffsmartclient.utils.httputils.MyUrlConfig;
import com.ffsmartclient.utils.httputils.Response;
import com.ffsmartclient.utils.MyJsonUtil;
import com.ffsmartclient.utils.MyToastUtil;
import com.google.gson.reflect.TypeToken;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * User Account Registration Page Controller
 *
 * @author Wenjia Geng
 */

public class RegisterActivity extends AppCompatActivity {

    private EditText edit_firstName;
    private EditText edit_lastName;
    private EditText edit_email;
    private EditText edit_password;
    private EditText edit_confirm_password;
    private RadioButton radio_driver;
    private RadioButton radio_chef;
    private RadioButton radio_headchef;

    protected Activity context;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        context = this;

        ImageView iv_back;
        Button btn_register;
        iv_back = findViewById(R.id.iv_back);
        edit_firstName = findViewById(R.id.edit_firstName);
        edit_lastName = findViewById(R.id.edit_lastName);
        edit_email = findViewById(R.id.edit_email);
        edit_password = findViewById(R.id.edit_password);
        edit_confirm_password = findViewById(R.id.edit_confirm_password);
        btn_register = findViewById(R.id.btn_register);
        radio_driver = findViewById(R.id.radio_driver);
        radio_chef = findViewById(R.id.radio_chef);
        radio_headchef = findViewById(R.id.radio_headchef);

        /**
         * Click on the Register button to create an account for the user
         */
        btn_register.setOnClickListener(v -> register());

        //Return to the login page
        iv_back.setOnClickListener(v -> finish());
    }

    /**
     * Check if the username is empty
     */
    protected boolean checkUserName(String firstName, String lastName){
        if ("".equals(firstName.trim())) {
            MyToastUtil.show(context, "Please enter your first name");
            return false;
        } else if ("".equals(lastName.trim())) {
            MyToastUtil.show(context, "Please enter your last name");
            return false;
        } else {
            return true;
        }
    }

    /**
     * Check the format of the Email
     */
    protected boolean checkEmailFormat(String email){
        boolean emailCheckPass = Pattern.matches("^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,6}$", email);
        if (!emailCheckPass) {
            MyToastUtil.show(context, "Wrong Email Format");
            return false;
        } else {
            return true;
        }
    }

    /**
     * Check the format of the password
     */
    protected boolean checkPasswordFormat(String password){
        boolean passwordCheckPass = Pattern.matches("^(?!\\d+$)(?![a-zA-Z]+$)[0-9A-Za-z]{6,10}$", password);
        if (!passwordCheckPass) {
            MyToastUtil.show(context, "Wrong Password Format");
            return false;
        } else {
            return true;
        }
    }

    /**
     * Check if the password entered matched
     */
    protected boolean checkPasswordMatched(String password, String cPassword){
        if (!password.equals(cPassword)) {
            MyToastUtil.show(context, "The password doesn't match");
            return false;
        } else {
            return true;
        }
    }

    /**
     * Check if user role is selected
     */
    protected boolean checkRoleSelected(){
        if (!radio_driver.isChecked() && !radio_chef.isChecked() && !radio_headchef.isChecked()) {
            MyToastUtil.show(context, "Please select role");
            return false;
        } else {
            return true;
        }
    }

    /**
     * Create an account
     */
    private void register() {
        String firstName = edit_firstName.getText().toString();
        String lastName = edit_lastName.getText().toString();
        String email = edit_email.getText().toString();
        String password = edit_password.getText().toString();
        String cPassword = edit_confirm_password.getText().toString();

        //Check if the username is empty
        if (!checkUserName(firstName, lastName)) {
            return;
        }

        //Check the format of the Email
        if (!checkEmailFormat(email)) {
            return;
        }

        //Check the format of the password
        //The password cannot be made up of all numbers or all alphabets.
        //The password should be a mixture of 6 to 10 digits or letters.
        if (!checkPasswordFormat(password)) {
            return;
        }

        //Check if the password entered matched
        if (!checkPasswordMatched(password, cPassword)) {
            return;
        }

        //Check if user role is selected
        if (!checkRoleSelected()) {
            return;
        }
        //assign role value
        int role = 0;
        if (radio_driver.isChecked()) {
            role = 0;
        } else if (radio_chef.isChecked()) {
            role = 1;
        } else if (radio_headchef.isChecked()) {
            role = 2;
        }

        //Create a new user object
        User user = new User();
        user.setFirstName(firstName);
        user.setLastName(lastName);
        user.setEmail(email);
        user.setPassword(password);
        user.setRole(role);

        /**
         * Send a POST method "user registration" request to the server
         */
        MyHttpUtil.post(MyUrlConfig.user, user, "POST", new MyHttpCallbackUtil() {
            @Override
            public void onSuccess(String data) {
                //Get the result of whether the registration has been successful or not
                Response<LoginToken> result = MyJsonUtil.fromJson(data, new TypeToken<Response<LoginToken>>() {
                }.getType());
                //Pop-up on the page indicating the result
                MyToastUtil.show(context, result.getMsg());
                //Close the current page if the registration successful
                if (result.getData() != null) {
                    LoginToken resultToken = result.getData();
                    User loginUser = resultToken.getUser();
                    String token = resultToken.getToken();

                    SPUtils.getInstance().put("user_json", data);//Store login user information with "user_json" key
                    SPUtils.getInstance().put(loginUser.getId(), token);//Save token with user ID
                    Intent intent = new Intent();
                    //Go to home page
                    intent.setClass(context, MainActivity.class);
                    startActivity(intent);
                    //Close the current page
                    finish();
                }
            }

            @Override
            public void onFailure(String data) {
                FailureResponse<String> result = MyJsonUtil.fromJson(data, new TypeToken<FailureResponse<String>>() {
                }.getType());
                MyToastUtil.show(context, result.getMsg());
            }
        });
    }
}