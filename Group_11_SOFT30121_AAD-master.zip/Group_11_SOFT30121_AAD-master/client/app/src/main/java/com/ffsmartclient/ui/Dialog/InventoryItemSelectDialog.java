/*
 * NTU Wenjia Geng (c) All rights reserved
 * None of this code can be reproduced or partly re-used without the permission
 * from Wenjia Geng (wenjia.geng2020@my.ntu.ac.uk).
 */
package com.ffsmartclient.ui.dialog;

import android.app.Dialog;
import android.content.Context;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import androidx.annotation.NonNull;

import com.ffsmartclient.model.Inventory;
import com.ffsmartclient.R;
import com.ffsmartclient.utils.httputils.FailureResponse;
import com.ffsmartclient.utils.httputils.MyHttpCallbackUtil;
import com.ffsmartclient.utils.httputils.MyHttpUtil;
import com.ffsmartclient.utils.httputils.MyUrlConfig;
import com.ffsmartclient.utils.httputils.Response;
import com.ffsmartclient.utils.MyJsonUtil;
import com.ffsmartclient.utils.MyToastUtil;
import com.ffsmartclient.ui.adapter.MyAdapter;
import com.ffsmartclient.ui.adapter.ViewHolder;
import com.google.gson.reflect.TypeToken;

import java.util.List;

/**
 * Inventory Items Select Dialog
 *
 * @author Wenjia Geng
 */

public class InventoryItemSelectDialog extends Dialog {

    private EditText edit_search;
    private Button btn_search;
    private ListView listView;
    private List<Inventory> inventoryItemList;


    public InventoryItemSelectDialog(@NonNull Context context, Callback callback) {
        super(context);
        setContentView(R.layout.dialog_item);
        //Display dialog
        show();
        edit_search = findViewById(R.id.edit_search);
        btn_search = findViewById(R.id.btn_search);
        listView = findViewById(R.id.listView);


        listView.setOnItemClickListener((adapterView, view, i, l) -> {
            if(inventoryItemList != null && inventoryItemList.size()>i){
                Inventory inventoryItem = inventoryItemList.get(i);
                callback.onCall(inventoryItem);
                dismiss();
            }
        });


        //Get All Available Inventory Items
        MyHttpUtil.getWithToken(MyUrlConfig.inventory,"GET", new MyHttpCallbackUtil() {
            @Override
            public void onSuccess(String data) {
                Response<List<Inventory>> result = MyJsonUtil.fromJson(data, new TypeToken<Response<List<Inventory>>>(){}.getType());
                if(result != null){
                    inventoryItemList = result.getData();
                    MyAdapter<Inventory> adapter = new MyAdapter<Inventory>(context, inventoryItemList, R.layout.item_inventory){
                        @Override
                        public void convert(ViewHolder helper, Inventory inventoryItem, int position) {
                            helper.setText(R.id.tv_itemName, inventoryItem.getItemName());
                            helper.setText(R.id.tv_expiryDate, "Expiry date: "+inventoryItem.getExpiryDate());
                        }
                    };
                    listView.setAdapter(adapter);
                }
            }

            @Override
            public void onFailure(String data){
                FailureResponse<String> result = MyJsonUtil.fromJson(data, new TypeToken<FailureResponse<String>>(){}.getType());
                MyToastUtil.show(context, result.getMsg());

            }
        });




        /**
         * Search for items available
         */
        btn_search.setOnClickListener(v -> {
            String itemName = edit_search.getText().toString();

            //get all item available
            MyHttpUtil.getWithToken(MyUrlConfig.inventory + "?itemName=" + itemName, "GET", new MyHttpCallbackUtil() {
                @Override
                public void onSuccess(String data) {
                    Response<List<Inventory>> result = MyJsonUtil.fromJson(data, new TypeToken<Response<List<Inventory>>>(){}.getType());
                    if(result != null){
                        inventoryItemList = result.getData();
                        MyAdapter<Inventory> adapter = new MyAdapter<Inventory>(context, inventoryItemList, R.layout.item_inventory){
                            @Override
                            public void convert(ViewHolder helper, Inventory inventoryItem, int position) {
                                helper.setText(R.id.tv_itemName, inventoryItem.getItemName());
                                helper.setText(R.id.tv_expiryDate, "Expiry date: "+inventoryItem.getExpiryDate());
                            }
                        };
                        listView.setAdapter(adapter);
                    }
                }

                @Override
                public void onFailure(String data){
                    FailureResponse<String> result = MyJsonUtil.fromJson(data, new TypeToken<FailureResponse<String>>(){}.getType());
                    MyToastUtil.show(context, result.getMsg());
                }
            });
        });
    }

    /**
     * CityDat callback interface (need override)
     */
    public interface Callback {
        void onCall(Inventory inventoryItem);
    }
}