package com.ffsmartclient;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.closeSoftKeyboard;
import static androidx.test.espresso.action.ViewActions.typeText;

import static androidx.test.espresso.intent.Intents.intended;
import static androidx.test.espresso.intent.matcher.IntentMatchers.hasComponent;
import static androidx.test.espresso.matcher.ViewMatchers.withId;

import androidx.test.espresso.intent.Intents;
import androidx.test.rule.ActivityTestRule;
import androidx.test.runner.AndroidJUnit4;

import com.ffsmartclient.ui.activity.LoginActivity;
import com.ffsmartclient.ui.activity.MainActivity;

import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

@RunWith(AndroidJUnit4.class)
public class LoginActivityUITest {
    @Rule
    public ActivityTestRule<LoginActivity> rule=new ActivityTestRule<LoginActivity>(LoginActivity.class,true);
    @Test
    public void test_whenLoginSuccess_thenGoMain() throws InterruptedException {
        Intents.init();
        onView(withId(R.id.edit_email)).perform(typeText("t1@gmail.com"),closeSoftKeyboard());
        onView(withId(R.id.edit_password)).perform(typeText("123123b"),closeSoftKeyboard());
        onView(withId(R.id.btn_login)).perform(click());
        Thread.sleep(3000);
        intended(hasComponent(MainActivity.class.getName()));
        Intents.release();
    }
}
