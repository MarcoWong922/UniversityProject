
package com.ffsmartclient;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.closeSoftKeyboard;
import static androidx.test.espresso.action.ViewActions.typeText;

import static androidx.test.espresso.intent.Intents.intended;
import static androidx.test.espresso.intent.matcher.IntentMatchers.hasComponent;
import static androidx.test.espresso.matcher.ViewMatchers.withId;

import androidx.test.espresso.intent.Intents;
import androidx.test.rule.ActivityTestRule;
import androidx.test.runner.AndroidJUnit4;

import com.ffsmartclient.ui.activity.MainActivity;
import com.ffsmartclient.ui.activity.RegisterActivity;

import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

@RunWith(AndroidJUnit4.class)
public class RegisterActivityUITest {

    @Rule
    public ActivityTestRule<RegisterActivity> rule=new ActivityTestRule<RegisterActivity>(RegisterActivity.class,true);

    @Test
    public void test_whenRegisterSuccess_thenGoMainPage() throws InterruptedException {
        Intents.init();
        onView(withId(R.id.radio_driver)).perform(click());
        onView(withId(R.id.edit_firstName)).perform(typeText("Wenjia3"),closeSoftKeyboard());
        onView(withId(R.id.edit_lastName)).perform(typeText("Geng"),closeSoftKeyboard());
        onView(withId(R.id.edit_email)).perform(typeText("t17@gmail.com"),closeSoftKeyboard());
        onView(withId(R.id.edit_password)).perform(typeText("123123b"),closeSoftKeyboard());
        onView(withId(R.id.edit_confirm_password)).perform(typeText("123123b"),closeSoftKeyboard());
        onView(withId(R.id.btn_register)).perform(click());
        Thread.sleep(3000);
        intended(hasComponent(MainActivity.class.getName()));
        Intents.release();
    }

}