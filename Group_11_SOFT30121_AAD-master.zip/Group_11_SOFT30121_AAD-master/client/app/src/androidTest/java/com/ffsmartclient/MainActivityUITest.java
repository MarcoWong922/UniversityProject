package com.ffsmartclient;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;

import static androidx.test.espresso.intent.Intents.intended;
import static androidx.test.espresso.intent.matcher.IntentMatchers.hasComponent;
import static androidx.test.espresso.matcher.ViewMatchers.withId;

import androidx.test.espresso.intent.Intents;
import androidx.test.rule.ActivityTestRule;
import androidx.test.runner.AndroidJUnit4;

import com.ffsmartclient.ui.activity.AlertActivity;
import com.ffsmartclient.ui.activity.InsertActivity;
import com.ffsmartclient.ui.activity.InventoryActivity;
import com.ffsmartclient.ui.activity.InventoryChangeActivity;
import com.ffsmartclient.ui.activity.LoginActivity;
import com.ffsmartclient.ui.activity.MainActivity;
import com.ffsmartclient.ui.activity.MyProfileActivity;
import com.ffsmartclient.ui.activity.OrdersActivity;
import com.ffsmartclient.ui.activity.RemoveActivity;
import com.ffsmartclient.ui.activity.ReportsActivity;
import com.ffsmartclient.ui.activity.SuppliersActivity;
import com.ffsmartclient.ui.activity.UserAccountActivity;

import org.junit.FixMethodOrder;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;

@RunWith(AndroidJUnit4.class)
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class MainActivityUITest {

    @Rule
    public ActivityTestRule<MainActivity> rule=new ActivityTestRule<MainActivity>(MainActivity.class,true);

    @Test
    public void test01whenClickSystemAlertBtn_thenGoAlert() throws InterruptedException {
        Intents.init();
        onView(withId(R.id.btn_alert)).perform(click());
        Thread.sleep(2000);
        intended(hasComponent(AlertActivity.class.getName()));
        onView(withId(R.id.iv_back)).perform(click());
        Intents.release();
    }

    @Test
    public void test02whenClickUserManagementBtn_thenGoUserManagement() throws InterruptedException {
        Intents.init();
        onView(withId(R.id.btn_userManagement)).perform(click());
        Thread.sleep(2000);
        intended(hasComponent(UserAccountActivity.class.getName()));
        onView(withId(R.id.iv_back)).perform(click());
        Intents.release();
    }


    @Test
    public void test03whenClickReportBtn_thenGoReport() throws InterruptedException {
        Intents.init();
        onView(withId(R.id.btn_reports)).perform(click());
        Thread.sleep(2000);
        intended(hasComponent(ReportsActivity.class.getName()));
        onView(withId(R.id.iv_back)).perform(click());
        Intents.release();
    }

    @Test
    public void test04whenClickAllOrdersBtn_thenGoAllOrders() throws InterruptedException {
        Intents.init();
        onView(withId(R.id.btn_order)).perform(click());
        Thread.sleep(2000);
        intended(hasComponent(OrdersActivity.class.getName()));
        onView(withId(R.id.iv_back)).perform(click());
        Intents.release();
    }

    @Test
    public void test05whenClickInsertBtn_thenGoInsert() throws InterruptedException {
        Intents.init();
        onView(withId(R.id.btn_insert)).perform(click());
        Thread.sleep(2000);
        intended(hasComponent(InsertActivity.class.getName()));
        onView(withId(R.id.iv_back)).perform(click());
        Intents.release();
    }

    @Test
    public void test06whenClickRemoveBtn_thenGoRemove() throws InterruptedException {
        Intents.init();
        onView(withId(R.id.btn_remove)).perform(click());
        Thread.sleep(2000);
        intended(hasComponent(RemoveActivity.class.getName()));
        onView(withId(R.id.iv_back)).perform(click());
        Intents.release();
    }

    @Test
    public void test07whenClickInventoryBtn_thenGoInventory() throws InterruptedException {
        Intents.init();
        onView(withId(R.id.btn_inventory)).perform(click());
        Thread.sleep(2000);
        intended(hasComponent(InventoryActivity.class.getName()));
        onView(withId(R.id.iv_back)).perform(click());
        Intents.release();
    }

    @Test
    public void test08whenClickSuppliersBtn_thenGoSuppliers() throws InterruptedException {
        Intents.init();
        onView(withId(R.id.btn_supplier)).perform(click());
        Thread.sleep(2000);
        intended(hasComponent(SuppliersActivity.class.getName()));
        onView(withId(R.id.iv_back)).perform(click());
        Intents.release();
    }

    @Test
    public void test09whenClickMyProfileBtn_thenGoMyProfile() throws InterruptedException {
        Intents.init();
        onView(withId(R.id.btn_profile)).perform(click());
        Thread.sleep(2000);
        intended(hasComponent(MyProfileActivity.class.getName()));
        onView(withId(R.id.iv_back)).perform(click());
        Intents.release();
    }


    @Test
    public void test10whenClickInventoryChangesBtn_thenGoInventoryChanges() throws InterruptedException {
        Intents.init();
        onView(withId(R.id.btn_history)).perform(click());
        Thread.sleep(2000);
        intended(hasComponent(InventoryChangeActivity.class.getName()));
        onView(withId(R.id.iv_back)).perform(click());
        Intents.release();
    }

    @Test
    public void test11whenClickLogoutBtn_thenGoLogin() throws InterruptedException {
        Intents.init();
        onView(withId(R.id.btn_logout)).perform(click());
        Thread.sleep(2000);
        intended(hasComponent(LoginActivity.class.getName()));
        Intents.release();
    }
}