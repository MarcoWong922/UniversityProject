# FFsmart

The Git repository for Group 11 SOFT30121 coursework.

NTU SOFT30121 Group 11 (c) All rights reserved. 
None of this code can be reproduced or partly re-used without permission from Wenjia Geng (wenjia.geng2020@my.ntu.ac.uk) & Oliver Wortley (oliver.wortley2022@my.ntu.ac.uk).
