package com.aad.ffsmart;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FfsmartApplicationTests {

	@Test
	void contextLoads() {
	}

}
